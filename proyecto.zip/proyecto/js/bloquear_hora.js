document.addEventListener("DOMContentLoaded", function () {
  const fecha1 = document.getElementById("fecha_turno");
  const hora1  = document.getElementById("hora_turno");
  const fecha2 = document.getElementById("fecha_turno_2");
  const hora2  = document.getElementById("hora_turno2");

  // Crear div para mensaje si no existe
  let mensajeHora = document.getElementById("mensaje_hora");
  if (!mensajeHora) {
    mensajeHora = document.createElement("div");
    mensajeHora.id = "mensaje_hora";
    mensajeHora.style.color = "red";
    mensajeHora.style.fontSize = "0.9rem";
    mensajeHora.style.marginTop = "0.25rem";
    hora2.parentNode.appendChild(mensajeHora);
  }

  function bloquearHora2() {
    // Habilitar todo antes
    for (let option of hora2.options) {
      option.disabled = false;
      option.style.color = "";
    }

    const mismasFechas = fecha1.value && fecha2.value && fecha1.value === fecha2.value;
    const seleccion1   = hora1.value;

    if (mismasFechas && seleccion1 !== "") {
      for (let option of hora2.options) {
        if (option.value === seleccion1) {
          option.disabled = true;
          option.style.color = "red";
        }
      }
      if (hora2.value === seleccion1) {
        mensajeHora.textContent = `La hora ${seleccion1} ya fue seleccionada en el primer turno.`;
      }
    }

    // BORRAR MENSAJE si las horas ya no son iguales
    if (hora1.value !== "" && hora2.value !== "" && hora1.value !== hora2.value) {
      mensajeHora.textContent = "";
    }
  }

  // Eventos para ejecutar bloqueo
  hora1.addEventListener("change", bloquearHora2);
  hora2.addEventListener("change", bloquearHora2);
  fecha1.addEventListener("change", bloquearHora2);
  fecha2.addEventListener("change", bloquearHora2);

  // Inicializar
  bloquearHora2();
});
