document.addEventListener("DOMContentLoaded", function () {
  const fechaInput = document.getElementById("fecha_turno");
  let horaSelect = document.getElementById("hora_turno2");

  function crearSelectHoras(ocupadas = []) {
    const select = document.createElement("select");
    select.name = "hora_turno2";
    select.id = "hora_turno2";
    select.className = "form-control";

    const inicio = 10 * 60; 
    const fin = 18 * 60;    

    for (let i = inicio; i <= fin; i += 25) {
      const horas = Math.floor(i / 60).toString().padStart(2, "0");
      const minutos = (i % 60).toString().padStart(2, "0");
      const valor = `${horas}:${minutos}`;

      const option = document.createElement("option");
      option.value = valor;

      if (ocupadas.includes(valor)) {
        option.disabled = true;
        option.style.color = "#888"; 
        option.textContent = `${valor} (Ocupado)`;
      } else {
        option.textContent = `${valor} (Disponible)`;
      }

      select.appendChild(option);
    }
    return select;
  }

  function actualizarHoras(ocupadas = []) {
    const viejoSelect = document.getElementById("hora_turno2");
    if (viejoSelect) {
      const nuevoSelect = crearSelectHoras(ocupadas);
      viejoSelect.replaceWith(nuevoSelect);
      horaSelect = nuevoSelect;
    }
  }

  fechaInput.addEventListener("change", function () {
    const fechaSeleccionada = new Date(this.value);
    const esDomingo = fechaSeleccionada.getDay() === 0;

    if (esDomingo) {
      alert("La barbería no trabaja los domingos. Por favor, seleccioná otro día.");
      this.value = "";
      actualizarHoras(); 
      return;
    }

    fetch(`obtener_horarios_ocupados.php?fecha=${this.value}`)
      .then(response => response.json())
      .then(data => {
        actualizarHoras(data);
      })
      .catch(() => {
        actualizarHoras();
      });
  });

  if (horaSelect && horaSelect.tagName.toLowerCase() === "input") {
    actualizarHoras();
  }
});
