// Sistema de pantallas de loading para la barbería
class LoadingManager {
  constructor() {
    this.createLoadingOverlay();
  }

  createLoadingOverlay() {
    // Crear el overlay de loading si no existe
    if (!document.querySelector('.loading-overlay')) {
      const overlay = document.createElement('div');
      overlay.className = 'loading-overlay';
      overlay.innerHTML = `
        <div class="loading-content">
          <div class="loading-spinner"></div>
          <div class="loading-text">Iniciando sesión...</div>
          <div class="loading-subtitle">Por favor espera...</div>
          <div class="loading-progress">
            <div class="loading-progress-bar"></div>
          </div>
        </div>
      `;
      document.body.appendChild(overlay);
    }
  }

  showLoading(action = 'login', customText = null) {
    const overlay = document.querySelector('.loading-overlay');
    const loadingText = overlay.querySelector('.loading-text');
    const loadingSubtitle = overlay.querySelector('.loading-subtitle');

    // Configurar texto según la acción
    switch (action) {
      case 'login':
        loadingText.textContent = customText || 'Iniciando sesión...';
        loadingSubtitle.textContent = 'Verificando credenciales...';
        overlay.classList.add('login');
        break;
      case 'logout':
        loadingText.textContent = customText || 'Cerrando sesión...';
        loadingSubtitle.textContent = 'Cerrando tu sesión...';
        overlay.classList.add('logout');
        break;
      case 'register':
        loadingText.textContent = customText || 'Registrando...';
        loadingSubtitle.textContent = 'Creando tu cuenta...';
        overlay.classList.add('register');
        break;
      default:
        loadingText.textContent = customText || 'Procesando...';
        loadingSubtitle.textContent = 'Por favor espera...';
    }

    // Mostrar el overlay
    overlay.classList.add('show');
    
    // Simular progreso (opcional)
    this.simulateProgress();
  }

  hideLoading() {
    const overlay = document.querySelector('.loading-overlay');
    if (overlay) {
      overlay.classList.remove('show');
      // Remover clases específicas
      overlay.classList.remove('login', 'logout', 'register');
    }
  }

  simulateProgress() {
    // Simular progreso para dar sensación de actividad
    const progressBar = document.querySelector('.loading-progress-bar');
    if (progressBar) {
      progressBar.style.animation = 'progress 2s ease-in-out infinite';
    }
  }

  // Método para mostrar loading con texto personalizado
  showCustomLoading(text, subtitle = 'Por favor espera...') {
    const overlay = document.querySelector('.loading-overlay');
    const loadingText = overlay.querySelector('.loading-text');
    const loadingSubtitle = overlay.querySelector('.loading-subtitle');

    loadingText.textContent = text;
    loadingSubtitle.textContent = subtitle;
    overlay.classList.add('show');
    this.simulateProgress();
  }

  // Método para mostrar loading con duración específica
  showLoadingWithDuration(action, duration = 2000) {
    this.showLoading(action);
    
    setTimeout(() => {
      this.hideLoading();
    }, duration);
  }
}

// Crear instancia global
window.loadingManager = new LoadingManager();

// Función helper para mostrar loading rápidamente
function showLoading(action, text) {
  if (window.loadingManager) {
    window.loadingManager.showLoading(action, text);
  }
}

// Función helper para ocultar loading
function hideLoading() {
  if (window.loadingManager) {
    window.loadingManager.hideLoading();
  }
}

// Función helper para loading personalizado
function showCustomLoading(text, subtitle) {
  if (window.loadingManager) {
    window.loadingManager.showCustomLoading(text, subtitle);
  }
}

// Función para manejar formularios con loading
function handleFormWithLoading(formId, action, customText = null) {
  const form = document.getElementById(formId);
  if (!form) return;
  
  form.addEventListener('submit', function(e) {
    e.preventDefault(); // Prevenir envío inmediato
    
    // Mostrar loading
    showLoading(action, customText);
    
    // Enviar formulario después de un pequeño delay para que se vea el loading
    setTimeout(() => {
      form.submit();
    }, 500);
  });
}
