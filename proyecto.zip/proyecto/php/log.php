<?php
session_start();
include("conexion.php");

if (isset($_POST['email']) && isset($_POST['clave'])) {
    $email = $_POST['email'];
    $clave = $_POST['clave'];

    $stmt = $con->prepare("SELECT id, nombre, pass, rol FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows === 1) {
        $usuario = $resultado->fetch_assoc();

        if (password_verify($clave, $usuario['pass'])) {
      
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario_nombre'] = $usuario['nombre'];
            $_SESSION['usuario_rol'] = $usuario['rol'];  

            // Mostrar pantalla de loading antes de redirigir
            ?>
            <!DOCTYPE html>
            <html lang="es">
            <head>
                <meta charset="UTF-8">
                <title>Iniciando sesión...</title>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" href="../css/loading.css" />
            </head>
            <body style="background: #1c1c1c;">
                <div class="loading-overlay show login">
                    <div class="loading-content">
                        <div class="loading-spinner"></div>
                        <div class="loading-text">¡Sesión iniciada!</div>
                        <div class="loading-subtitle">Redirigiendo...</div>
                        <div class="loading-progress">
                            <div class="loading-progress-bar"></div>
                        </div>
                    </div>
                </div>
                
                <script src="../js/loading.js"></script>
                <script>
                    // Mostrar loading por 2 segundos y luego redirigir
                    setTimeout(function() {
                        <?php if ($usuario['rol'] === 'admin'): ?>
                            window.location.href = 'panel_admin.php';
                        <?php else: ?>
                            window.location.href = 'index2.php';
                        <?php endif; ?>
                    }, 2000);
                </script>
            </body>
            </html>
            <?php
            exit;
        } else {
            // Mostrar pantalla de loading para error de contraseña
            ?>
            <!DOCTYPE html>
            <html lang="es">
            <head>
                <meta charset="UTF-8">
                <title>Error de contraseña</title>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" href="../css/loading.css" />
            </head>
            <body style="background: #1c1c1c;">
                <div class="loading-overlay show login">
                    <div class="loading-content">
                        <div class="loading-spinner"></div>
                        <div class="loading-text">Contraseña incorrecta</div>
                        <div class="loading-subtitle">Redirigiendo...</div>
                        <div class="loading-progress">
                            <div class="loading-progress-bar"></div>
                        </div>
                    </div>
                </div>
                
                <script src="../js/loading.js"></script>
                <script>
                    setTimeout(function() {
                        window.history.back();
                    }, 2000);
                </script>
            </body>
            </html>
            <?php
            exit;
        }
    } else {
        // Mostrar pantalla de loading para error de correo
        ?>
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <title>Correo no encontrado</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="../css/loading.css" />
        </head>
        <body style="background: #1c1c1c;">
            <div class="loading-overlay show login">
                <div class="loading-content">
                    <div class="loading-spinner"></div>
                    <div class="loading-text">Correo no encontrado</div>
                    <div class="loading-subtitle">Redirigiendo...</div>
                    <div class="loading-progress">
                        <div class="loading-progress-bar"></div>
                    </div>
                </div>
            </div>
            
            <script src="../js/loading.js"></script>
            <script>
                setTimeout(function() {
                    window.history.back();
                }, 2000);
            </script>
        </body>
        </html>
        <?php
        exit;
    }
    $stmt->close();

    } else {
    // Mostrar pantalla de loading para acceso no permitido
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Acceso no permitido</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/loading.css" />
    </head>
    <body style="background: #1c1c1c;">
        <div class="loading-overlay show login">
            <div class="loading-content">
                <div class="loading-spinner"></div>
                <div class="loading-text">Acceso no permitido</div>
                <div class="loading-subtitle">Redirigiendo...</div>
                <div class="loading-progress">
                    <div class="loading-progress-bar"></div>
                </div>
            </div>
        </div>
        
        <script src="../js/loading.js"></script>
        <script>
            setTimeout(function() {
                window.location.href = 'login.php';
            }, 2000);
        </script>
    </body>
    </html>
    <?php
    exit;
}
?>
