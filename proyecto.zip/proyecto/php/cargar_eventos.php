<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'admin') {
  http_response_code(403);
  exit();
}

// Consulta modificada para obtener todos los detalles del turno, uniendo todas las tablas necesarias
$sql = "SELECT 
            t.id, t.fecha, t.hora, t.descripcion, t.whatsapp, t.senia, t.estado, t.cancelacion_motivo, t.fecha_turno_2, t.hora_turno_2,
            u.nombre AS cliente, 
            s.nombre AS servicio, 
            s2.nombre AS servicio_2, 
            b.nombre AS barbero, 
            mp.nombre AS metodo_pago_nombre
        FROM turnos t
        JOIN usuarios u ON t.usuario_id = u.id
        JOIN servicios s ON t.servicio = s.id
        LEFT JOIN servicios_extra s2 ON t.servicio_2 = s2.id
        LEFT JOIN barberos b ON t.barbero = b.id
        JOIN metodos_pago mp ON t.metodo_pago = mp.id
        WHERE t.estado = 'activo'";

$stmt = $con->prepare($sql);
$stmt->execute();
$res = $stmt->get_result();

$eventos = [];
while ($row = $res->fetch_assoc()) {
  // Definimos las propiedades extendidas que usará el calendario
  $extendedProps = [
    'cliente' => htmlspecialchars($row['cliente']),
    'servicio' => htmlspecialchars($row['servicio']),
    'barbero' => htmlspecialchars($row['barbero'] ?? 'Cualquiera'),
    'descripcion' => htmlspecialchars($row['descripcion']),
    'whatsapp' => (bool)$row['whatsapp'],
    'metodo_pago_nombre' => htmlspecialchars($row['metodo_pago_nombre']),
    'senia' => htmlspecialchars($row['senia']),
    'estado' => htmlspecialchars($row['estado']),
    'cancelacion_motivo' => htmlspecialchars($row['cancelacion_motivo'] ?? '-')
  ];

  // Turno principal
  $eventos[] = [
    'id' => $row['id'],
    'title' => $row['cliente'] . ' - ' . $row['servicio'],
    'start' => $row['fecha'] . 'T' . $row['hora'],
    'extendedProps' => $extendedProps
  ];

  // Segundo turno, si existe
  if (!empty($row['fecha_turno_2']) && !empty($row['hora_turno_2'])) {
    $eventos[] = [
      'id' => $row['id'] . '-2',
      'title' => $row['cliente'] . ' - ' . ($row['servicio_2'] ?: 'Servicio extra'),
      'start' => $row['fecha_turno_2'] . 'T' . $row['hora_turno_2'],
      'extendedProps' => $extendedProps
    ];
  }
}

header('Content-Type: application/json');
echo json_encode($eventos);