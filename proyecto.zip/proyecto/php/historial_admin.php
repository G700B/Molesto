<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'admin') {
    header("Location: login.php");
    exit();
}

if (isset($_GET['limpiar']) && $_GET['limpiar'] == '1') {
    $con->query("DELETE FROM turnos");
    header("Location: historial_admin.php?borrado=1");
    exit();
}

$sql = "SELECT t.*, u.nombre AS cliente, s.nombre AS servicio, b.nombre AS barbero, 
                mp.nombre AS metodo_pago_nombre
        FROM turnos t
        JOIN usuarios u ON t.usuario_id = u.id
        JOIN servicios s ON t.servicio = s.id
        LEFT JOIN barberos b ON t.barbero = b.id
        JOIN metodos_pago mp ON t.metodo_pago = mp.id
        ORDER BY t.fecha DESC, t.hora DESC";

$stmt = $con->prepare($sql);
$stmt->execute();
$resultado = $stmt->get_result();
$turnos = $resultado->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">
<head>
    <meta charset="UTF-8" />
    <title>Historial de Turnos - Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #1c1c1c;
            color: #e0e0e0;
            scroll-behavior: smooth;
             zoom: 0.6;
        }
        header {
            background: transparent !important;
            position: fixed;
            width: 100%;
            z-index: 1000;
            transition: background-color 0.3s ease;
        }
        header.transparent {
            background-color: transparent !important;
        }
        header.solid {
            background-color: #1c1c1c !important;
        }

        /* Estilos del menú replicados */
        header .container-fluid {
            padding-top: 2.5rem;
            padding-bottom: 2.5rem;
        }
        .navbar-brand.blend-logo {
            font-weight: 600;
            letter-spacing: 3px;
            font-size: 4rem;
        }
        .nav-link {
            font-size: 1.5rem;
            font-weight: 600;
            letter-spacing: 1.5px;
            color: #E0E0E0 !important;
            transition: color 0.3s ease;
            padding: 2rem 3rem !important;
        }
        .btn-book-now {
            background-color: #A38C6C;
            color: #fff;
            border: none;
            font-weight: 600;
            padding: 25px 50px;
            transition: all 0.3s ease;
            font-size: 1.4rem;
        }
        .nav-link:hover {
            color: #C7A86D !important;
        }
        .btn-book-now:hover {
            background-color: #8C7B5D;
            transform: scale(1.05);
        }

        .navbar-brand span {
            font-weight: 600;
            letter-spacing: 1px;
        }
        .btn-primary {
            background-color: #c7a86d;
            border: none;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #b08f56;
            transform: scale(1.05);
        }
        .btn-outline-light:hover {
            background-color: #f1f1f1;
            color: #000;
        }
        h1, h2, h3, h4 {
            font-family: inherit;
        }
        section {
            padding: 6rem 0;
        }
        .accent {
            color: #c7a86d;
        }
        .fade-in {
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 0.8s ease, transform 0.8s ease;
        }
        .fade-in.visible {
            opacity: 1;
            transform: translateY(0);
        }
        
        /* Estilos específicos para el panel de admin */
        #inicio {
            background: linear-gradient(to bottom, rgba(0,0,0,0.5), rgba(0,0,0,0.85)), url('../img/one.jpg') center/cover no-repeat;
            color: white;
            text-align: center;
            min-height: 200vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }
        .main-container {
            padding-top: 15rem; 
            padding-bottom: 2rem;
        }
        .card-turno {
            background: rgba(42, 42, 42, 0.9);
            color: #e0e0e0;
            border-radius: 12px;
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.4);
            padding: 1.5rem;
            transition: box-shadow 0.3s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .card-turno:hover {
            box-shadow: 0 1rem 2rem rgba(0,0,0,0.6);
        }
        .card-turno h5 {
            font-weight: 600;
            margin-bottom: 1rem;
            color: #c7a86d;
        }
        .badge {
            font-size: 0.85rem;
        }
        .btn-outline-danger {
            border-color: #dc3545;
            color: #dc3545;
        }
        .btn-outline-danger:hover {
            background-color: #dc3545;
            color: #fff;
        }
        .alert-success {
            background-color: #28a745;
            border-color: #28a745;
            color: #fff;
        }
        .alert-warning {
            background-color: #ffc107;
            border-color: #ffc107;
            color: #000;
        }
    </style>
</head>
<body>

<header class="p-3 transparent">
    <div class="container-fluid d-flex flex-wrap justify-content-between align-items-center">
        <a href="panel_admin.php" class="navbar-brand blend-logo text-white text-decoration-none ms-3">
            BLEND
        </a>
        <ul class="nav mb-2 mb-md-0 d-flex">
            <li><a href="panel_admin.php" class="nav-link px-3 text-white">PANEL</a></li>
            <li><a href="agregar_admin.php" class="nav-link px-3 text-white">AGREGAR ADMIN</a></li>
            <li><a href="historial_admin.php" class="nav-link px-3 accent">HISTORIAL</a></li>
            <li><a href="servicio_admin.php" class="nav-link px-3 text-white">SERVICIOS</a></li>
        </ul>
        <div class="text-end d-flex align-items-center gap-3 me-3">
            <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <i class="fa-solid fa-user-shield"></i> <?= htmlspecialchars($_SESSION['usuario_nombre']) ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar sesión</a></li>
                </ul>
            </div>
        </div>
    </div>
</header>

<section id="inicio" class="d-flex flex-column justify-content-center align-items-center text-center fade-in">
    <div class="container main-container">
        <h2 class="text-center fw-bold my-4 accent">
            <i class="fa fa-history me-3"></i>Historial de Turnos
        </h2>

        <?php if (isset($_GET['borrado']) && $_GET['borrado'] == '1'): ?>
            <div class="alert alert-success text-center shadow-sm border border-success border-2 rounded">
                Historial eliminado correctamente.
            </div>
        <?php endif; ?>

        <div>
            <?php if (empty($turnos)): ?>
                <div class="alert alert-warning text-center shadow-sm border border-warning border-2 rounded">
                    <i class="fa fa-info-circle me-2"></i>No hay turnos registrados.
                </div>
            <?php else: ?>
                <div class="row g-4">
                    <?php foreach ($turnos as $turno): ?>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card-turno" style="border-radius: 15px; background-color: rgba(255,255,255,0.6); color:black;">
                                <h5>
                                    <i class="fa fa-calendar-days me-2"></i><?= htmlspecialchars($turno['fecha']) ?> - <?= htmlspecialchars($turno['hora']) ?>
                                </h5>
                                <p><strong>Cliente:</strong> <?= htmlspecialchars($turno['cliente']) ?></p>
                                <p><strong>Servicio:</strong> <?= htmlspecialchars($turno['servicio']) ?></p>
                                <p><strong>Barbero:</strong> <?= htmlspecialchars($turno['barbero'] ?? 'Cualquiera') ?></p>
                                <p><strong>Descripción:</strong> <?= htmlspecialchars($turno['descripcion']) ?></p>
                                <p>
                                    <strong>WhatsApp:</strong> 
                                    <?= $turno['whatsapp'] ? '<span class="text-success">✅</span>' : '<span class="text-danger">❌</span>' ?>
                                </p>
                                <p><strong>Método de Pago:</strong> <?= htmlspecialchars($turno['metodo_pago_nombre']) ?></p>
                                <p><strong>Seña:</strong> 
                                    <?php 
                                        if (!empty($turno['senia'])) {
                                            echo '$' . number_format($turno['senia'], 0, ',', '.');
                                        } else {
                                            echo '-';
                                        }
                                    ?>
                                </p>
                                <p>
                                    <strong>Estado:</strong>
                                    <?php 
                                        $estado = $turno['estado'];
                                        if ($estado === 'activo') {
                                            echo '<span class="badge bg-success">Activo</span>';
                                        } elseif ($estado === 'cancelado') {
                                            echo '<span class="badge bg-danger">Cancelado</span>';
                                        } else {
                                            echo '<span class="badge bg-secondary">'.htmlspecialchars($estado).'</span>';
                                        }
                                    ?>
                                </p>
                                <p><strong>Motivo Cancelación:</strong> <?= htmlspecialchars($turno['cancelacion_motivo'] ?? '-') ?></p>
                                <a style="background-color: #fde88bff; color: #000;" href="../pdf/tutorial/tuto_admi.php?turno_id=<?= $turno['id'] ?>" target="_blank" class="btn btn-primary w-100 mt-2">
                                    <i class="fa fa-file-pdf me-2"></i>Ver Comprobante
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
    
            <?php if (!empty($turnos)): ?>
                <div class="d-flex justify-content-end mt-4">
                    <a href="historial_admin.php?limpiar=1" class="btn btn-outline-danger shadow-sm border-2 rounded"
                       onclick="return confirm('¿Seguro que deseas borrar todo el historial?');">
                        <i class="fa fa-trash me-2"></i>Limpiar Historial
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<footer class="py-5" style="background-color: #1c1c1c; color: #e0e0e0;">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-3">
                <p class="mb-1">&copy; 2025 Barbería Estilo</p>
                <a href="#" class="text-decoration-none text-secondary me-2">Privacy Policy</a>|
                <a href="#" class="text-decoration-none text-secondary mx-2">Terms of Service</a>|
                <a href="#" class="text-decoration-none text-secondary ms-2">Website Design by YourName</a>
            </div>
            <div class="col-md-4 mb-3 text-center">
                <p class="mb-2">Follow us:</p>
                <a href="https://www.instagram.com/kevin477_/" target="_blank" class="text-white me-3">
                    <i class="fa-brands fa-instagram fa-lg accent"></i>
                </a>
                <a href="#" class="text-white me-3">
                    <i class="fa-brands fa-facebook fa-lg accent"></i>
                </a>
                <a href="#" class="text-white">
                    <i class="fa-brands fa-whatsapp fa-lg accent"></i>
                </a>
            </div>
            <div class="col-md-4 mb-3">
                <p class="mb-1"><strong>Contact:</strong></p>
                <p class="mb-1">Tel: 443-643-8903</p>
                <p class="mb-1">Email: info@barberiaestilo.com</p>
                <p class="mb-0"><strong>Hours:</strong></p>
                <p class="mb-0">Mon - Thurs: 9am - 8pm</p>
                <p class="mb-0">Fri: 9am - 8pm</p>
                <p class="mb-0">Sat: 9am - 4pm</p>
                <p class="mb-0">Sun: Closed</p>
            </div>
        </div>
        <div class="text-center mt-4">
            <a href="#top" class="btn btn-outline-light btn-sm">Back to top</a>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const faders = document.querySelectorAll('.fade-in');
    const appearOptions = { threshold: 0.2, rootMargin: "0px 0px -50px 0px" };
    const appearOnScroll = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if(entry.isIntersecting){
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, appearOptions);
    faders.forEach(fader => appearOnScroll.observe(fader));

    const header = document.querySelector('header');
    window.addEventListener('scroll', () => {
      if(window.scrollY > window.innerHeight - 50){
   header.classList.remove('transparent');
   header.classList.add('solid');
} else {
   header.classList.remove('solid');
   header.classList.add('transparent');
}

    });
</script>
</body>
</html>