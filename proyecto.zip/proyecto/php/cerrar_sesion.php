<?php
session_start();
session_destroy();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Cerrando sesión...</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/loading.css" />
</head>
<body style="background: #1c1c1c;">
  <div class="loading-overlay show logout">
    <div class="loading-content">
      <div class="loading-spinner"></div>
      <div class="loading-text">Cerrando sesión...</div>
      <div class="loading-subtitle">Cerrando tu sesión...</div>
      <div class="loading-progress">
        <div class="loading-progress-bar"></div>
      </div>
    </div>
  </div>
  
  <script src="../js/loading.js"></script>
  <script>
    // Mostrar loading por 2 segundos y luego redirigir
    setTimeout(function() {
      window.location.href = '../index.php';
    }, 2000);
  </script>
</body>
</html>
