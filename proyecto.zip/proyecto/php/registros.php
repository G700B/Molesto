<?php
include("conexion.php");

if (isset($_POST['email'])) {
    $nombre     = $_POST['nombre'];
    $apellido   = $_POST['apellido'];
    $fecha_nac  = $_POST['fecha_nac'];
    $telefono   = $_POST['telefono'];
    $email      = $_POST['email'];
    $clave      = $_POST['clave'];

    $stmt = $con->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->close();
        // Mostrar pantalla de loading antes de redirigir
        ?>
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <title>Error en registro</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="../css/loading.css" />
        </head>
        <body style="background: #1c1c1c;">
            <div class="loading-overlay show register">
                <div class="loading-content">
                    <div class="loading-spinner"></div>
                    <div class="loading-text">Correo ya registrado</div>
                    <div class="loading-subtitle">Redirigiendo...</div>
                    <div class="loading-progress">
                        <div class="loading-progress-bar"></div>
                    </div>
                </div>
            </div>
            
            <script src="../js/loading.js"></script>
            <script>
                // Mostrar loading por 2 segundos y luego redirigir
                setTimeout(function() {
                    window.location.href = 'registro.php?error=existe';
                }, 2000);
            </script>
        </body>
        </html>
        <?php
        exit;
    }
    $stmt->close();

    $clave_encriptada = password_hash($clave, PASSWORD_DEFAULT);

    $stmt = $con->prepare("INSERT INTO usuarios (nombre, apellido, fecha, telefono, email, pass) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $nombre, $apellido, $fecha_nac, $telefono, $email, $clave_encriptada);

    if ($stmt->execute()) {
        $stmt->close();
        // Mostrar pantalla de loading antes de redirigir
        ?>
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <title>Registro exitoso</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="../css/loading.css" />
        </head>
        <body style="background: #1c1c1c;">
            <div class="loading-overlay show register">
                <div class="loading-content">
                    <div class="loading-spinner"></div>
                    <div class="loading-text">¡Cuenta creada exitosamente!</div>
                    <div class="loading-subtitle">Redirigiendo al login...</div>
                    <div class="loading-progress">
                        <div class="loading-progress-bar"></div>
                    </div>
                </div>
            </div>
            
            <script src="../js/loading.js"></script>
            <script>
                // Mostrar loading por 2 segundos y luego redirigir
                setTimeout(function() {
                    window.location.href = 'login.php?registro=ok';
                }, 2000);
            </script>
        </body>
        </html>
        <?php
        exit;
    } else {
        $stmt->close();
        header("Location: registro.php?error=1");
        exit;
    }

} else {
    // Mostrar pantalla de loading para acceso no permitido
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Acceso no permitido</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/loading.css" />
    </head>
    <body style="background: #1c1c1c;">
        <div class="loading-overlay show register">
            <div class="loading-content">
                <div class="loading-spinner"></div>
                <div class="loading-text">Acceso no permitido</div>
                <div class="loading-subtitle">Redirigiendo...</div>
                <div class="loading-progress">
                    <div class="loading-progress-bar"></div>
                </div>
            </div>
        </div>
        
        <script src="../js/loading.js"></script>
        <script>
            setTimeout(function() {
                window.location.href = 'registro.php?error=acceso';
            }, 2000);
        </script>
    </body>
    </html>
    <?php
    exit;
}
?>
