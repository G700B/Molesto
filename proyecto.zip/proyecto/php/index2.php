<?php
session_start();
include 'conexion.php';
?>
<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Reservar Turno - Barbería Estilo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
<link rel="stylesheet" href="../css/loading.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css" />
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #ffffffff;
      color: #e0e0e0;
      min-height: 100vh;
      scroll-behavior: smooth;
      zoom: 0.6;
    }

    header{
      background: transparent !important;
      position: fixed;
      width: 100%;
      z-index: 1000;
      transition: background-color 0.3s ease;
    }

    header.transparent {
      background-color: transparent !important;
    }

    header.solid {
      background-color: #1c1c1c !important;
    }

    /* Estilos del menú replicados */
    header .container-fluid {
      padding-top: 2.5rem;
      padding-bottom: 2.5rem;
    }

    .navbar-brand.blend-logo {
      font-weight: 600;
      letter-spacing: 3px;
      font-size: 4rem;
    }

    .nav-link {
      font-size: 1.5rem;
      font-weight: 600;
      letter-spacing: 1.5px;
      color: #E0E0E0 !important;
      transition: color 0.3s ease;
      padding: 2rem 3rem !important;
    }

    .btn-book-now {
      background-color: #A38C6C;
      color: #fff;
      border: none;
      font-weight: 600;
      padding: 25px 50px;
      transition: all 0.3s ease;
      font-size: 1.4rem;
    }

    .nav-link:hover {
      color: #C7A86D !important;
    }

    .btn-book-now:hover {
      background-color: #8C7B5D;
      transform: scale(1.05);
    }

    .accent {
      color: #c7a86d;
    }

    h1,
    h2,
    h3,
    h4 {
      font-family: inherit;
    }

    section {
      padding: 6rem 0;
    }

    #inicio {
      background: linear-gradient(to bottom, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.85)), url('../img/one.jpg') center/cover no-repeat;
      color: white;
      text-align: center;
      min-height: 200vh;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
    }

    #inicio h1 {
      font-size: 3rem;
      font-weight: 700;
      margin-bottom: 1rem;
    }

    /* --- ESTILO DEL FORMULARIO COPIADO DE LOGIN --- */
    .form-section {
      background: rgba(255, 255, 255, 0.2);
      backdrop-filter: blur(5px);
      border-radius: 25px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
      padding: 80px;
      max-width: 600px;
      width: 100%;
      color: #e0e0e0;
      font-family: 'Segoe UI', sans-serif;
    }

    .form-section h3,
    .form-section p,
    .form-section label {
      color: #e0e0e0;
    }

    .form-control {
      border-radius: 10px;
      padding: 20px;
      font-size: 1.25rem;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: #fff;
    }

    .form-control::placeholder {
      color: rgba(255, 255, 255, 0.7);
    }

    .btn-login,
    .btn-primary {
      background: #c7a86d;
      border: none;
      border-radius: 10px;
      width: 100%;
      padding: 20px;
      font-size: 1.5rem;
      font-weight: bold;
      color: #fff;
      transition: background 0.3s;
    }

    .btn-login:hover,
    .btn-primary:hover {
      background: #b08f56;
    }

    .forgot-link a {
      color: #c7a86d;
      text-decoration: none;
    }

    .forgot-link a:hover {
      text-decoration: underline;
    }

    .turno-activo-box {
      background-color: #2a2a2a;
      border-radius: 12px;
      padding: 3rem;
      box-shadow: 0 12px 25px rgba(0, 0, 0, 0.6);
      color: #e0e0e0;
    }

    .turno-activo-box .btn-outline-primary {
      color: #c7a86d;
      border-color: #c7a86d;
      transition: all 0.3s ease;
    }

    .turno-activo-box .btn-outline-primary:hover {
      background-color: #c7a86d;
      color: #fff;
    }

    footer {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      padding: 2rem 0;
      text-align: center;
    }

    .fade-in {
      opacity: 0;
      transform: translateY(20px);
      transition: opacity 0.8s ease, transform 0.8s ease;
    }

    .fade-in.visible {
      opacity: 1;
      transform: translateY(0);
    }
  </style>
</head>

<body>

  <header class="p-3 transparent">
    <div class="container-fluid d-flex flex-wrap justify-content-between align-items-center">
      <a href="#" class="navbar-brand blend-logo text-white text-decoration-none ms-3">
        BLEND
      </a>
      <ul class="nav mb-2 mb-md-0 d-flex">
        <li><a href="index2.php" class="nav-link px-3 text-white">INICIO</a></li>
        <li><a href="#servicios" class="nav-link px-3 text-white"> SERVICES</a></li>
        <li><a href="ver_turno.php" class="nav-link px-3 text-white">VER TURNO</a></li>
        <li><a href="tienda2.php" class="nav-link px-3 text-white">TIENDA</a></li>
        
        <li><a href="historial.php" class="nav-link px-3 text-white">HISTORIAL</a></li>
        <li><a href="#" class="nav-link px-3 text-white">CONTACT</a></li>
      </ul>
      <?php if (isset($_SESSION['usuario_nombre'])): ?>
        <div class="dropdown">
          <button class="btn btn-book-now dropdown-toggle" type="button" data-bs-toggle="dropdown">
            <i class="fa-solid fa-user"></i> <?= htmlspecialchars($_SESSION['usuario_nombre']) ?>
          </button>
          <ul class="dropdown-menu dropdown-menu-end">
            
            <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar sesión</a></li>
          </ul>
        </div>
      <?php else: ?>
        <a href="login.php" class="btn btn-book-now me-3">
          LOGIN <i class="fa-solid fa-chevron-down ms-2" style="font-size: 0.8em;"></i>
        </a>
      <?php endif; ?>
    </div>
  </header>

  <section id="inicio" class="d-flex flex-column justify-content-center align-items-center text-center fade-in"><br><br><br><br><br><br>
    <p class="lead mb-4">Agenda tu cita con los mejores estilistas de la ciudad</p>
    <h1 class="fw-bold">Reserva tu turno online.</h1>
    
  <?php
  $turno_activo = false;
  if (isset($_SESSION['usuario_id'])) {
    $usuario_id = $_SESSION['usuario_id'];
    $consulta_turno = "SELECT * FROM turnos WHERE usuario_id = ? AND estado = 'activo'";
    $stmt = $con->prepare($consulta_turno);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $resultado_turno = $stmt->get_result();
    $turno_activo = $resultado_turno->fetch_assoc();
  }
  ?>

  <?php if (isset($_SESSION['usuario_nombre'])): ?>
    <section class="d-flex align-items-center justify-content-center py-5 fade-in">
      <div class="container d-flex flex-column flex-md-row align-items-center justify-content-center gap-5">
        <div class="benefits text-center text-md-start">
          <h2 class="mb-3 accent">Reservá tu turno</h2>
          <ul class="list-unstyled fs-5">
            <li><i class="fa-solid fa-check-circle me-2 accent"></i>Elegí día, horario y barbero.</li>
            <li><i class="fa-solid fa-check-circle me-2 accent"></i>Contanos cómo querés tu corte.</li>
            <li><i class="fa-solid fa-check-circle me-2 accent"></i>Confirmación por WhatsApp.</li>
            <hr class="text-secondary" />
            <li><i class="fa-solid fa-calendar-xmark me-2 text-danger"></i><strong>No trabajamos los domingos</strong>
            </li>
            <li><i class="fa-solid fa-clock me-2 accent"></i><strong>Horario:</strong> de 10:00 a 18:00 hs</li>
          </ul>
        </div>
        <?php if (!$turno_activo): ?>
          <div class="form-section fade-in" style="max-width: 420px; padding: 50px;">
            <h4 class="text-center mb-3 text-white">Reservar Turno</h4>
            <form action="reservar_turno.php" method="POST">
              <div class="mb-3">
                <label for="fecha_turno" class="form-label">Fecha del turno</label>
                <input type="text" class="form-control" id="fecha_turno" name="fecha_turno" required />
              </div>
              <div class="mb-3">
                <label for="hora_turno" class="form-label">Hora</label>
                <input type="time" class="form-control" id="hora_turno" name="hora_turno" required />
              </div>
              <div class="mb-3">
                <label for="servicio" class="form-label">Servicio</label>
                <select class="form-select" id="servicio" name="servicio" required>
                  <option value="">Seleccione un servicio</option>
                  <?php
                  $query_servicios = "SELECT id, nombre, precio FROM servicios";
                  $resultado_servicios = $con->query($query_servicios);
                  while ($servicio = $resultado_servicios->fetch_assoc()):
                    ?>
                    <option value="<?= $servicio['id'] ?>">
                      <?= htmlspecialchars($servicio['nombre']) ?> - $<?= number_format($servicio['precio'], 2) ?>
                    </option>
                  <?php endwhile; ?>
                </select>
              </div>
              <div class="mb-3">
                <label for="descripcion" class="form-label">¿Cómo querés tu corte?</label>
                <textarea class="form-control" id="descripcion" name="descripcion" rows="3"
                  placeholder="Ej: Fade alto con barba definida..." required></textarea>
              </div>
              <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="servicio_extra_check" name="servicio_extra_check" />
                <label class="form-check-label" for="servicio_extra_check">
                  Quiero realizarme otro servicio aparte del corte
                </label>
              </div>
              <div id="servicio_extra_container"
                style="display: none; border: 1px solid rgba(255,255,255,0.3); padding: 15px; border-radius: 8px; margin-bottom: 1rem;">
                <h5 class="mb-3 text-white">Servicio adicional</h5>
                <div class="mb-3">
                  <label for="fecha_turno_2" class="form-label">Fecha del segundo turno</label>
                  <input type="text" class="form-control" id="fecha_turno_2" name="fecha_turno_2" />
                </div>
                <div class="mb-3">
                  <label for="hora_turno2" class="form-label">Hora del segundo turno</label>
                  <input type="time" class="form-control" id="hora_turno2" name="hora_turno_2" required />
                </div>
                <div class="mb-3">
                  <label for="servicio_2" class="form-label">Servicio adicional</label>
                  <select class="form-select" id="servicio_2" name="servicio_2">
                    <option value="">Seleccione un servicio</option>
                    <?php
                    $query_servicios_extra = "SELECT id, nombre, precio FROM servicios_extra";
                    $resultado_servicios_extra = $con->query($query_servicios_extra);
                    while ($servicio_extra = $resultado_servicios_extra->fetch_assoc()):
                      ?>
                      <option value="<?= $servicio_extra['id'] ?>">
                        <?= htmlspecialchars($servicio_extra['nombre']) ?> -
                        $<?= number_format($servicio_extra['precio'], 2) ?>
                      </option>
                    <?php endwhile; ?>
                  </select>
                </div>
              </div>
              <div class="mb-3">
                <label for="barbero" class="form-label">Barbero preferido</label>
                <select class="form-select" id="barbero" name="barbero">
                  <option value="">Cualquiera</option>
                  <?php
                  $query_barberos = "SELECT id, nombre FROM barberos WHERE estado = 1";
                  $resultado_barberos = $con->query($query_barberos);
                  while ($barbero = $resultado_barberos->fetch_assoc()):
                    ?>
                    <option value="<?= $barbero['id'] ?>"><?= htmlspecialchars($barbero['nombre']) ?></option>
                  <?php endwhile; ?>
                </select>
              </div>
              <div class="mb-3">
                <label for="metodo_pago" class="form-label">Método de pago</label>
                <select class="form-select" id="metodo_pago" name="metodo_pago" required>
                  <option value="">Seleccione un método</option>
                  <?php
                  $query_metodos = "SELECT id, nombre FROM metodos_pago";
                  $resultado_metodos = $con->query($query_metodos);
                  while ($metodo = $resultado_metodos->fetch_assoc()):
                    ?>
                    <option value="<?= $metodo['id'] ?>"><?= htmlspecialchars($metodo['nombre']) ?></option>
                  <?php endwhile; ?>
                </select>
              </div>
              <div class="form-check mb-4">
                <input class="form-check-input" type="checkbox" id="whatsapp_confirm" name="whatsapp_confirm" value="1" />
                <label class="form-check-label" for="whatsapp_confirm">
                  Deseo recibir confirmación por WhatsApp
                </label>
              </div>
              <div class="mb-3" id="seña-container" style="display: none;">
                <label for="sena" class="form-label">Seña (adelanto)</label>
                <input type="number" step="0.01" min="0" class="form-control" id="sena" name="sena"
                  placeholder="Ingrese el monto de la seña" />
              </div>
              <button type="submit" class="btn btn-login w-100">Confirmar Turno</button>
            </form>
          </div>
        <?php else: ?>
          <div class="turno-activo-box fade-in text-center">
            <h5 class="mb-3 accent">
              <i class="fa-solid fa-calendar-check me-2"></i>Turno ya registrado
            </h5>
            <p>Ya tenés un turno activo en el sistema.</p>
            <p>
              <a href="ver_turno.php" class="btn btn-outline-primary mt-2">Ver / Editar turno</a>
            </p>
          </div>
        <?php endif; ?>
      </div>
    </section>
  <?php else: ?>
    <div class="text-center mt-5 fade-in">
      <a href="login.php" class="btn btn-book-now btn-lg">Ingresar para reservar turno</a>
    </div>
  <?php endif; ?>
  </section>


<section id="servicios" class="py-5 fade-in" style="background-color: #fff; color: #000;">
 <div class="container">
  <h2 class="text-center mb-5 accent">Nuestros Servicios</h2>
  <div class="row g-4" style="background-color: #fff4c2ff; color: #000;">
   <div class="col-md-4 fade-in">
    <div class="card text-center h-100" style="background-color: #eee0e0ff; color: #000;">
     <i class="fa-solid fa-scissors fa-3x mb-3 accent"></i>
     <h4>Corte Clásico</h4>
     <p>Estilo tradicional con técnica profesional. Ideal para cualquier ocasión.</p>
    </div>
   </div>
   <div class="col-md-4 fade-in">
    <div class="card text-center h-100" style="background-color: #eee0e0ff; color: #000;">
     <i class="fa-solid fa-pen-ruler fa-3x mb-3 accent"></i>
     <h4>Diseños & Fade</h4>
     <p>Degradados y diseños personalizados para un look único.</p>
    </div>
   </div>
   <div class="col-md-4 fade-in">
    <div class="card text-center h-100" style="background-color: #eee0e0ff; color: #000;">
     <i class="fa-solid fa-spa fa-3x mb-3 accent"></i>
     <h4>Afeitado</h4>
     <p>Toalla caliente, espuma y precisión para una experiencia de barbería completa.</p>
    </div>
   </div>
  </div>
 </div>
</section>

  <div class="dark" style="background-color: #eee0e0ff; color: #e0e0e0;">
    <section class="container mt-5 fade-in">
      <div class="p-4 rounded" style="background-color: #2a2a2a; max-width: 600px; margin: auto;">
        <h5 class="text-white mb-3 accent">Dejá un comentario sobre la peluquería</h5>
        <form action="comen.php" method="POST" id="comentarioForm">
          <div class="mb-3">
            <textarea name="comentario" class="form-control" rows="3" placeholder="Escribí tu comentario..."
              required></textarea>
          </div>
          <button type="submit" class="btn btn-primary w-100">Enviar comentario</button>
        </form>
      </div>
    </section><br><br>
  </div>
  <footer class="py-5" style="background-color: #1c1c1c; color: #e0e0e0;">
    <div class="container">
      <div class="row">
        <div class="col-md-4 mb-3">
          <p class="mb-1">&copy; 2025 Barbería Estilo</p>
          <a href="#" class="text-decoration-none text-secondary me-2">Privacy Policy</a>|
          <a href="#" class="text-decoration-none text-secondary mx-2">Terms of Service</a>|
          <a href="#" class="text-decoration-none text-secondary ms-2">Website Design by YourName</a>
        </div>
        <div class="col-md-4 mb-3 text-center">
          <p class="mb-2">Follow us:</p>
          <a href="https://www.instagram.com/kevin477_/" target="_blank" class="text-white me-3">
            <i class="fa-brands fa-instagram fa-lg accent"></i>
          </a>
          <a href="#" class="text-white me-3">
            <i class="fa-brands fa-facebook fa-lg accent"></i>
          </a>
          <a href="#" class="text-white">
            <i class="fa-brands fa-whatsapp fa-lg accent"></i>
          </a>
        </div>
        <div class="col-md-4 mb-3">
          <p class="mb-1"><strong>Contact:</strong></p>
          <p class="mb-1">Tel: 443-643-8903</p>
          <p class="mb-1">Email: info@barberiaestilo.com</p>
          <p class="mb-0"><strong>Hours:</strong></p>
          <p class="mb-0">Mon - Thurs: 9am - 8pm</p>
          <p class="mb-0">Fri: 9am - 8pm</p>
          <p class="mb-0">Sat: 9am - 4pm</p>
          <p class="mb-0">Sun: Closed</p>
        </div>
      </div>
      <div class="text-center mt-4">
        <a href="#inicio" class="btn btn-outline-light btn-sm">Back to top</a>
      </div>
    </div>
  </footer>
  <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../js/loading.js"></script>
  <script src="../js/horario.js"></script>
  <script src="../js/horario2.js"></script>
  <script src="../js/bloquear_hora.js"></script>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      flatpickr("#fecha_turno", {
        dateFormat: "Y-m-d",
        minDate: "today",
        disable: [
          function (date) {
            return date.getDay() === 0;
          },
        ],
        locale: {
          firstDayOfWeek: 1,
        },
      });
      const metodoPagoSelect = document.getElementById("metodo_pago");
      const senaContainer = document.getElementById("seña-container");
      metodoPagoSelect.addEventListener("change", function () {
        const selectedMetodo = parseInt(this.value);
        if (!isNaN(selectedMetodo) && selectedMetodo !== 1) {
          senaContainer.style.display = "block";
        } else {
          senaContainer.style.display = "none";
        }
      });
      const servicioExtraCheck = document.getElementById("servicio_extra_check");
      const servicioExtraContainer = document.getElementById("servicio_extra_container");
      servicioExtraCheck.addEventListener("change", function () {
        if (this.checked) {
          servicioExtraContainer.style.display = "block";
          if (!servicioExtraContainer.dataset.flatpickr) {
            flatpickr("#fecha_turno_2", {
              dateFormat: "Y-m-d",
              minDate: "today",
              disable: [
                function (date) {
                  return date.getDay() === 0;
                },
              ],
              locale: {
                firstDayOfWeek: 1,
              },
            });
            servicioExtraContainer.dataset.flatpickr = "true";
          }
        } else {
          servicioExtraContainer.style.display = "none";
          document.getElementById("fecha_turno_2").value = "";
          document.getElementById("hora_turno2").value = "";
          document.getElementById("servicio_2").value = "";
        }
      });
    });
    const faders = document.querySelectorAll('.fade-in');
    const appearOptions = { threshold: 0.2, rootMargin: "0px 0px -50px 0px" };
    const appearOnScroll = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, appearOptions);
    faders.forEach(fader => appearOnScroll.observe(fader));
    
    // Sistema de loading para el formulario de comentarios
    handleFormWithLoading('comentarioForm', 'login', 'Enviando comentario...');
  </script>
</body>

</html>