<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Certified Invisible Bead Extensions® Stylists and Colorists in Baltimore, MD | Blend Salon</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        /* Se ha modificado el estilo del body para que aplique la fuente a todo el documento */
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #1c1c1c;
            /* negro más claro */
            color: #e0e0e0;
            scroll-behavior: smooth;
             zoom: 0.6;

        }

        header {
            background: transparent !important;
            position: fixed;
            width: 100%;
            z-index: 1000;
        }

        /* Modificaciones finales para que el menú sea extra grande */
        header .container-fluid {
            padding-top: 2.5rem;
            padding-bottom: 2.5rem;
        }

        .navbar-brand.blend-logo {
            /* Se ha quitado el font-family para que herede el estilo del body */
            font-weight: 600;
            letter-spacing: 3px;
            font-size: 4rem;
        }

        .nav-link {
            font-size: 1.5rem;
            font-weight: 600;
            letter-spacing: 1.5px;
            color: #E0E0E0 !important;
            transition: color 0.3s ease;
            padding: 2rem 3rem !important;
        }

        .btn-book-now {
            background-color: #A38C6C;
            color: #fff;
            border: none;
            font-weight: 600;
            padding: 25px 50px;
            transition: all 0.3s ease;
            font-size: 1.4rem;
        }

        .nav-link:hover {
            color: #C7A86D !important;
        }

        .btn-book-now:hover {
            background-color: #8C7B5D;
            transform: scale(1.05);
        }

        .navbar-brand span {
            font-weight: 600;
            letter-spacing: 1px;
        }

        .btn-primary {
            background-color: #c7a86d;
            border: none;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #b08f56;
            transform: scale(1.05);
        }

        .btn-outline-light:hover {
            background-color: #f1f1f1;
            color: #000;
        }

        /* Se ha quitado el font-family para que herede del body */
        h1,
        h2,
        h3,
        h4 {
            font-family: inherit;
        }

        section {
            padding: 6rem 0;
        }

        #inicio {
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.85)), url('../img/sty.webp') center/cover no-repeat;
            color: white;
            text-align: center;
            min-height: 200vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }

        #inicio h1 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }

        #servicios .card,
        #comentarios .card,
        #blend-style .card {
            background-color: #2a2a2a;
            border-radius: 12px;
            padding: 2rem;
            transition: transform 0.4s ease, box-shadow 0.4s ease;
        }

        #servicios .card:hover,
        #comentarios .card:hover,
        #blend-style .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.6);
        }

        /* Estilos para las imágenes de los estilistas */
        .stylist-img-container {
            width: 70%;
            height: 600px;
            border-radius: 50% 50% 0 0;
            overflow: hidden;
            margin-bottom: 1rem;
        }

        .stylist-img-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .stylist-info {
            text-align: center;
        }

        .stylist-info h3 {
            font-size: 1.5rem;
            font-weight: bold;
            margin-top: 1rem;
        }

        .stylist-info p {
            font-size: 1rem;
        }


        #nosotros,
        #servicios,
        #blend-style,
        #faq {
            background-color: #2a2a2a;
            /* gris oscuro */
            color: #e0e0e0;
            border-radius: 12px;
            padding: 3rem;
        }

        #faq .accordion-item {
            background-color: #2a2a2a;
            border-radius: 12px;
            margin-bottom: 1rem;
        }

        footer {
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding: 2rem 0;
            text-align: center;
        }

        .accent {
            color: #c7a86d;
        }

        #blend-style img {
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
            width: 100%;
            height: auto;
            object-fit: cover;
        }

        /* Fade-in animation */
        .fade-in {
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 0.8s ease, transform 0.8s ease;
        }

        .fade-in.visible {
            opacity: 1;
            transform: translateY(0);
        }


        header {
            position: fixed;
            width: 100%;
            z-index: 1000;
            transition: background-color 0.3s ease;
        }

        header.transparent {
            background-color: transparent !important;
        }

        header.solid {
            background-color: #4F433C !important;
        }
    </style>
</head>

<body>

    <header class="p-3 transparent">
        <div class="container-fluid d-flex flex-wrap justify-content-between align-items-center">
            <a href="#inicio" class="navbar-brand blend-logo text-white text-decoration-none ms-3">
                BLEND
            </a>

            <ul class="nav mb-2 mb-md-0 d-flex">
                <li><a href="../index.php" class="nav-link px-3 text-white">INICIO</a></li>
                <li><a href="#" class="nav-link px-3 text-white"> SERVICES</a></li>
                <li><a href="#" class="nav-link px-3 text-white">COLOR SERVICES</a></li>
                <li><a href="#" class="nav-link px-3 text-white">BLOWOUTS</a></li>
                <li><a href="#stylists" class="nav-link px-3 text-white">STYLISTS</a></li>
                <li><a href="#" class="nav-link px-3 text-white">CAREERS</a></li>
                <li><a href="#" class="nav-link px-3 text-white">CONTACT</a></li>
            </ul>

            <a href="login.php" class="btn btn-book-now me-3">
                LOGIN <i class="fa-solid fa-chevron-down ms-2" style="font-size: 0.8em;"></i>
            </a>
        </div>
    </header>

    <section id="inicio" class="d-flex flex-column justify-content-center align-items-center text-center fade-in">
        <p class="lead mb-4">Certified Invisible Bead Extensions® Stylists and Colorists in Baltimore, MD | Blend Salon
        </p>

        <h1 class="fw-bold">Our stylists are certified with Invisible Bead Extensions and specialize in Custom Coloring,
            including blonding & color transformations.</h1>

    </section>


    <section id="stylists" class="py-5 fade-in" style="background-color: #ffffffff; color: #000;">
        <div class="container">
            <h2 class="text-center mb-5 accent">Meet Our Stylists</h2>
            <div class="row g-4 justify-content-center">
                <div class="col-md-6 fade-in mb-4 d-flex flex-column align-items-center">
                    <div class="stylist-img-container">
                        <img src="../img/one.jpg" alt="Kelsey" class="img-fluid">
                    </div>
                    <div class="stylist-info">
                        <h3>KELSEY</h3>
                        <p>Owner, Color and Blonding Specialist, Invisible Bead Extensions® Master Technician</p>
                        <a href="#" class="btn btn-primary mt-2">LEARN MORE ABOUT KELSEY</a>
                    </div>
                </div>
                <div class="col-md-6 fade-in mb-4 d-flex flex-column align-items-center">
                    <div class="stylist-img-container">
                        <img src="../img/one.jpg" alt="Ashley" class="img-fluid">
                    </div>
                    <div class="stylist-info">
                        <h3>KEVIN</h3>
                        <p>Owner, Color & Blonding Specialist, Invisible Bead Extensions® Elite Artist, Salon Educator
                        </p>
                        <a href="#" class="btn btn-primary mt-2">LEARN MORE ABOUT ASHLEY</a>
                    </div>
                </div>
                <div class="col-md-6 fade-in mb-4 d-flex flex-column align-items-center">
                    <div class="stylist-img-container">
                        <img src="../img/one.jpg" alt="Jenna" class="img-fluid">
                    </div>
                    <div class="stylist-info">
                        <h3>JENNA</h3>
                        <p>Lived in Color Specialist, Newly Certified IBE Artist, Level 1 Stylist</p>
                        <a href="#" class="btn btn-primary mt-2">LEARN MORE ABOUT JENNA</a>
                    </div>
                </div>
                <div class="col-md-6 fade-in mb-4 d-flex flex-column align-items-center">
                    <div class="stylist-img-container">
                        <img src="../img/one.jpg" alt="Alex" class="img-fluid">
                    </div>
                    <div class="stylist-info">
                        <h3>ALEX</h3>
                        <p>Color & Blonding Specialist, Invisible Bead Extensions® Stylist, Newly Certified IBE Artist,
                            Level 1 Stylist</p>
                        <a href="#" class="btn btn-primary mt-2">LEARN MORE ABOUT ALEX</a>
                    </div>
                </div>
            </div>
        </div>
    </section>


    </div>
    <footer class="py-5" style="background-color: #1c1c1c; color: #e0e0e0;">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <p class="mb-1">&copy; 2025 Barbería Estilo</p>
                    <a href="#" class="text-decoration-none text-secondary me-2">Privacy Policy</a>|
                    <a href="#" class="text-decoration-none text-secondary mx-2">Terms of Service</a>|
                    <a href="#" class="text-decoration-none text-secondary ms-2">Website Design by YourName</a>
                </div>

                <div class="col-md-4 mb-3 text-center">
                    <p class="mb-2">Follow us:</p>
                    <a href="https://www.instagram.com/kevin477_/" target="_blank" class="text-white me-3">
                        <i class="fa-brands fa-instagram fa-lg accent"></i>
                    </a>
                    <a href="#" class="text-white me-3">
                        <i class="fa-brands fa-facebook fa-lg accent"></i>
                    </a>
                    <a href="#" class="text-white">
                        <i class="fa-brands fa-whatsapp fa-lg accent"></i>
                    </a>
                </div>

                <div class="col-md-4 mb-3">
                    <p class="mb-1"><strong>Contact:</strong></p>
                    <p class="mb-1">Tel: 443-643-8903</p>
                    <p class="mb-1">Email: info@barberiaestilo.com</p>
                    <p class="mb-0"><strong>Hours:</strong></p>
                    <p class="mb-0">Mon - Thurs: 9am - 8pm</p>
                    <p class="mb-0">Fri: 9am - 8pm</p>
                    <p class="mb-0">Sat: 9am - 4pm</p>
                    <p class="mb-0">Sun: Closed</p>
                </div>
            </div>

            <div class="text-center mt-4">
                <a href="#inicio" class="btn btn-outline-light btn-sm">Back to top</a>
            </div>
        </div>
    </footer>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Animación fade-in al hacer scroll
        const faders = document.querySelectorAll('.fade-in');
        const appearOptions = { threshold: 0.2, rootMargin: "0px 0px -50px 0px" };
        const appearOnScroll = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    observer.unobserve(entry.target);
                }
            });
        }, appearOptions);
        faders.forEach(fader => appearOnScroll.observe(fader));


        const header = document.querySelector('header');
        const inicio = document.querySelector('#inicio');

        window.addEventListener('scroll', () => {
            const inicioHeight = inicio.offsetHeight;
            if(window.scrollY > window.innerHeight - 50){
   header.classList.remove('transparent');
   header.classList.add('solid');
} else {
   header.classList.remove('solid');
   header.classList.add('transparent');
}

        });

    </script>

</body>

</html>