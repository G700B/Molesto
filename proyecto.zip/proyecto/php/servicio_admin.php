<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'admin') {
 header("Location: login.php");
 exit();
}

// Agregar servicio
if (isset($_POST['agregar'])) {
 $nombre = trim($_POST['nombre']);
 $precio = floatval($_POST['precio']);
 if (!empty($nombre) && $precio > 0) {
  $stmt = $con->prepare("INSERT INTO servicios (nombre, precio) VALUES (?, ?)");
  $stmt->bind_param("sd", $nombre, $precio);
  $stmt->execute();
  header("Location: " . $_SERVER['PHP_SELF']);
  exit();
 }
}

// Editar precio
if (isset($_POST['editar'])) {
 $id = intval($_POST['id']);
 $precio = floatval($_POST['precio']);
 if ($id > 0 && $precio > 0) {
  $stmt = $con->prepare("UPDATE servicios SET precio = ? WHERE id = ?");
  $stmt->bind_param("di", $precio, $id);
  $stmt->execute();
  header("Location: " . $_SERVER['PHP_SELF']);
  exit();
 }
}

// Eliminar servicio
if (isset($_POST['eliminar'])) {
 $id = intval($_POST['id']);
 if ($id > 0) {
  $stmt = $con->prepare("DELETE FROM servicios WHERE id = ?");
  $stmt->bind_param("i", $id);
  $stmt->execute();
  header("Location: " . $_SERVER['PHP_SELF']);
  exit();
 }
}

// Obtener lista de servicios
$result = $con->query("SELECT * FROM servicios ORDER BY nombre ASC");
$servicios = $result->fetch_all(MYSQLI_ASSOC);

// Agregar servicio extra
if (isset($_POST['agregar_extra'])) {
 $nombre = trim($_POST['nombre']);
 $precio = floatval($_POST['precio']);
 if (!empty($nombre) && $precio > 0) {
  $stmt = $con->prepare("INSERT INTO servicios_extra (nombre, precio) VALUES (?, ?)");
  $stmt->bind_param("sd", $nombre, $precio);
  $stmt->execute();
  header("Location: " . $_SERVER['PHP_SELF']);
  exit();
 }
}

// Editar precio servicio extra
if (isset($_POST['editar_extra'])) {
 $id = intval($_POST['id']);
 $precio = floatval($_POST['precio']);
 if ($id > 0 && $precio > 0) {
  $stmt = $con->prepare("UPDATE servicios_extra SET precio = ? WHERE id = ?");
  $stmt->bind_param("di", $precio, $id);
  $stmt->execute();
  header("Location: " . $_SERVER['PHP_SELF']);
  exit();
 }
}

// Eliminar servicio extra
if (isset($_POST['eliminar_extra'])) {
 $id = intval($_POST['id']);
 if ($id > 0) {
  $stmt = $con->prepare("DELETE FROM servicios_extra WHERE id = ?");
  $stmt->bind_param("i", $id);
  $stmt->execute();
  header("Location: " . $_SERVER['PHP_SELF']);
  exit();
 }
}

// Obtener lista de servicios extra
$result_extra = $con->query("SELECT * FROM servicios_extra ORDER BY nombre ASC");
$servicios_extra = $result_extra->fetch_all(MYSQLI_ASSOC);

// Agregar barbero
if (isset($_POST['agregar_barbero'])) {
 $nombre = trim($_POST['nombre']);
 $especialidad = trim($_POST['especialidad']);
 $estado = trim($_POST['estado']);
 if (!empty($nombre) && !empty($especialidad) && !empty($estado)) {
  $stmt = $con->prepare("INSERT INTO barberos (nombre, especialidad, estado) VALUES (?, ?, ?)");
  $stmt->bind_param("sss", $nombre, $especialidad, $estado);
  $stmt->execute();
  header("Location: " . $_SERVER['PHP_SELF']);
  exit();
 }
}

// Editar barbero
if (isset($_POST['editar_barbero'])) {
 $id = intval($_POST['id']);
 $nombre = trim($_POST['nombre']);
 $especialidad = trim($_POST['especialidad']);
 $estado = trim($_POST['estado']);
 if ($id > 0 && !empty($nombre) && !empty($especialidad) && !empty($estado)) {
  $stmt = $con->prepare("UPDATE barberos SET nombre = ?, especialidad = ?, estado = ? WHERE id = ?");
  $stmt->bind_param("sssi", $nombre, $especialidad, $estado, $id);
  $stmt->execute();
  header("Location: " . $_SERVER['PHP_SELF']);
  exit();
 }
}

// Eliminar barbero
if (isset($_POST['eliminar_barbero'])) {
 $id = intval($_POST['id']);
 if ($id > 0) {
  $stmt = $con->prepare("DELETE FROM barberos WHERE id = ?");
  $stmt->bind_param("i", $id);
  $stmt->execute();
  header("Location: " . $_SERVER['PHP_SELF']);
  exit();
 }
}

// Obtener lista de barberos
$result_barberos = $con->query("SELECT * FROM barberos ORDER BY nombre ASC");
$barberos = $result_barberos->fetch_all(MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">
<head>
 <meta charset="UTF-8" />
 <title>Gestión de Servicios - Panel Admin</title>
 <meta name="viewport" content="width=device-width, initial-scale=1" />
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
 <style>
  body {
   font-family: 'Segoe UI', sans-serif;
   background-color: #1c1c1c;
   color: #e0e0e0;
   scroll-behavior: smooth;
    zoom: 0.6;
  }
  header {
   background: transparent !important;
   position: fixed;
   width: 100%;
   z-index: 1000;
   transition: background-color 0.3s ease;
  }
  header.transparent {
   background-color: transparent !important;
  }
  header.solid {
   background-color: #1c1c1c !important;
  }
  header .container-fluid {
   padding-top: 2.5rem;
   padding-bottom: 2.5rem;
  }
  .navbar-brand.blend-logo {
   font-weight: 600;
   letter-spacing: 3px;
   font-size: 4rem;
  }
  .nav-link {
   font-size: 1.5rem;
   font-weight: 600;
   letter-spacing: 1.5px;
   color: #E0E0E0 !important;
   transition: color 0.3s ease;
   padding: 2rem 3rem !important;
  }
  .nav-link:hover {
   color: #C7A86D !important;
  }
  .btn-primary {
   background-color: #c7a86d;
   border: none;
   transition: all 0.3s ease;
  }
  .btn-primary:hover {
   background-color: #b08f56;
   transform: scale(1.05);
  }
  h1, h2, h3, h4 {
   font-family: inherit;
  }
  section {
   padding: 6rem 0;
  }
  .accent {
   color: #c7a86d;
  }
  .fade-in {
   opacity: 0;
   transform: translateY(20px);
   transition: opacity 0.8s ease, transform 0.8s ease;
  }
  .fade-in.visible {
   opacity: 1;
   transform: translateY(0);
  }
  
  /* Estilos específicos para el panel de admin */
  #inicio {
   background: linear-gradient(to bottom, rgba(0,0,0,0.5), rgba(0,0,0,0.85)), url('../img/one.jpg') center/cover no-repeat;
   color: white;
   text-align: center;
   min-height: 200vh;
   display: flex;
   align-items: center;
   justify-content: center;
   flex-direction: column;
  }
  .main-container {
   padding-top: 15rem; 
   padding-bottom: 2rem;
  }
  .card-service {
   background: rgba(255, 255, 255, 0.1);
   color: #e0e0e0;
   border-radius: 12px;
   box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.4);
   padding: 1.5rem;
   transition: box-shadow 0.3s ease;
   height: 100%;
   display: flex;
   flex-direction: column;
   justify-content: space-between;
   border: 1px solid rgba(255, 255, 255, 0.1);
  }
  .card-service:hover {
   box-shadow: 0 1rem 2rem rgba(0,0,0,0.6);
  }
  .service-icon {
   font-size: 2.5rem;
   color: #c7a86d;
  }
  .price {
   font-weight: 700;
   font-size: 1.8rem;
   color: #28a745;
  }
  .service-name {
   font-weight: 600;
   font-size: 1.25rem;
   margin-bottom: 0.25rem;
   color: #e0e0e0;
  }
  .service-desc {
   font-size: 0.875rem;
   color: #adb5bd;
   min-height: 3rem;
   margin-bottom: 1rem;
  }
  .btn-outline-primary {
   border-color: #c7a86d;
   color: #c7a86d;
  }
  .btn-outline-primary:hover {
   background-color: #c7a86d;
   color: #fff;
  }
  .btn-outline-danger {
   border-color: #dc3545;
   color: #dc3545;
  }
  .btn-outline-danger:hover {
   background-color: #dc3545;
   color: #fff;
  }
  .btn-success {
   background-color: #28a745;
   border-color: #28a745;
  }
  .btn-success:hover {
   background-color: #218838;
   border-color: #1e7e34;
  }
  .form-control {
   background-color: rgba(255, 255, 255, 0.1);
   color: #e0e0e0;
   border: 1px solid rgba(255, 255, 255, 0.2);
  }
  .form-control::placeholder {
   color: #adb5bd;
  }
  
  /* Estilos para el acordeón */
  .accordion-item {
   background-color: transparent !important;
   border: none;
  }
  .accordion-button {
   background-color: #2a2a2a !important;
   color: #c7a86d !important;
   font-weight: bold;
   font-size: 1.5rem;
   border-radius: 12px;
   box-shadow: 0 0.25rem 0.5rem rgba(0,0,0,0.2);
  }
  .accordion-button:not(.collapsed) {
   background-color: #1c1c1c !important;
   color: #e0e0e0 !important;
  }
  .accordion-button:focus {
   box-shadow: 0 0 0 0.25rem rgba(199, 168, 109, 0.25) !important;
  }
  .accordion-body {
   background-color: #2a2a2a;
   border-radius: 0 0 12px 12px;
  }
 </style>
</head>
<body>

<header class="p-3 transparent">
 <div class="container-fluid d-flex flex-wrap justify-content-between align-items-center">
  <a href="panel_admin.php" class="navbar-brand blend-logo text-white text-decoration-none ms-3">
   BLEND
  </a>
  <ul class="nav mb-2 mb-md-0 d-flex">
   <li><a href="panel_admin.php" class="nav-link px-3 text-white">PANEL</a></li>
   <li><a href="agregar_admin.php" class="nav-link px-3 text-white">AGREGAR ADMIN</a></li>
   <li><a href="historial_admin.php" class="nav-link px-3 text-white">HISTORIAL</a></li>
   <li><a href="servicio_admin.php" class="nav-link px-3 accent">SERVICIOS</a></li>
  </ul>
  <div class="text-end d-flex align-items-center gap-3 me-3">
   <div class="dropdown">
    <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
     <i class="fa-solid fa-user-shield"></i> <?= htmlspecialchars($_SESSION['usuario_nombre']) ?>
    </button>
    <ul class="dropdown-menu dropdown-menu-end">
     <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar sesión</a></li>
    </ul>
   </div>
  </div>
 </div>
</header>

<section id="inicio" class="d-flex flex-column justify-content-center align-items-center text-center fade-in">
 <div class="container main-container">
  <h1 class="mb-4 text-center accent">
   <i class="fa fa-cogs me-3"></i>Gestión de Servicios
  </h1>
  
  <div class="accordion" id="serviciosAccordion">
   <div class="accordion-item">
    <h2 class="accordion-header" id="headingOne">
     <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
      <i class="fa-solid fa-gear me-3"></i> Servicios
     </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#serviciosAccordion">
     <div class="accordion-body">
      <div class="row g-4">
       <?php foreach ($servicios as $s): ?>
        <div class="col-md-4">
         <div class="card-service" style="border-radius: 15px; background-color: rgba(255, 255, 255, 0.5); color:black;">
          <div class="d-flex align-items-center mb-3">
           <i class="fas fa-cut service-icon me-3"></i>
           <div>
            <div class="service-name"><?= htmlspecialchars($s['nombre']) ?></div>
            <div class="price">$<?= number_format($s['precio'], 2) ?></div>
           </div>
          </div>
          <div style=" color:black;" class="service-desc"><?= htmlspecialchars($s['descripcion'] ?? '') ?></div>
 
          <form action="" method="post" class="mt-auto d-flex gap-2 align-items-center">
           <input type="hidden" name="id" value="<?= $s['id'] ?>">
           <input style=" color:black;" type="number" step="0.01" name="precio" value="<?= $s['precio'] ?>" class="form-control form-control-sm" style="max-width: 100px;" required>
           <button style=" color:black;" type="submit" name="editar" class="btn btn-outline-primary btn-sm" title="Editar precio">
            <i class="fa fa-pen"></i>
           </button>
           <button type="submit" name="eliminar" class="btn btn-outline-danger btn-sm" title="Eliminar servicio" onclick="return confirm('¿Eliminar servicio?');">
            <i class="fa fa-trash"></i>
           </button>
          </form>
         </div>
        </div>
       <?php endforeach; ?>
      </div>
      <hr class="my-5 accent">
      <h4 class="mb-3 accent">Agregar Nuevo Servicio</h4>
      <form action="" method="post" class="row g-3">
       <div class="col-md-6">
        <input type="text" name="nombre" class="form-control" placeholder="Nombre del servicio" required>
       </div>
       <div class="col-md-4">
        <input type="number" step="0.01" name="precio" class="form-control" placeholder="Precio" required>
       </div>
       <div class="col-md-2">
        <button type="submit" name="agregar" class="btn btn-success w-100">Agregar</button>
       </div>
      </form>
     </div>
    </div>
   </div>       <div class="accordion-item mt-4">
    <h2 class="accordion-header" id="headingTwo">
     <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
      <i class="fa-solid fa-star me-3"></i> Servicios Extra
     </button>
     </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#serviciosAccordion">
     <div class="accordion-body">
      <div class="row g-4">
       <?php foreach ($servicios_extra as $se): ?>
        <div class="col-md-4">
         <div class="card-service" style="border-radius: 15px; background-color: rgba(255, 255, 255, 0.5); color:black;">
          <div class="d-flex align-items-center mb-3">
           <i class="fas fa-star service-icon me-3"></i>
           <div>
            <div class="service-name"><?= htmlspecialchars($se['nombre']) ?></div>
            <div class="price">$<?= number_format($se['precio'], 2) ?></div>
           </div>
          </div>
          <form action="" method="post" class="mt-auto d-flex gap-2 align-items-center">
           <input type="hidden" name="id" value="<?= $se['id'] ?>">
           <input style=" color:black;" type="number" step="0.01" name="precio" value="<?= $se['precio'] ?>" class="form-control form-control-sm" style="max-width: 100px;" required>
           <button style=" color:black;" type="submit" name="editar_extra" class="btn btn-outline-primary btn-sm" title="Editar precio">
            <i class="fa fa-pen"></i>
           </button>
           <button type="submit" name="eliminar_extra" class="btn btn-outline-danger btn-sm" title="Eliminar servicio" onclick="return confirm('¿Eliminar servicio extra?');">
            <i class="fa fa-trash"></i>
           </button>
          </form>
         </div>
        </div>
       <?php endforeach; ?>
      </div>
      <hr class="my-5 accent">
      <h4 class="mb-3 accent">Agregar Nuevo Servicio Extra</h4>
      <form action="" method="post" class="row g-3">
       <div class="col-md-6">
        <input type="text" name="nombre" class="form-control" placeholder="Nombre del servicio extra" required>
       </div>
       <div class="col-md-4">
        <input type="number" step="0.01" name="precio" class="form-control" placeholder="Precio" required>
       </div>
       <div class="col-md-2">
        <button type="submit" name="agregar_extra" class="btn btn-success w-100">Agregar</button>
       </div>
      </form>
     </div>
    </div>
   </div>
   
      <div class="accordion-item mt-4">
    <h2 class="accordion-header" id="headingThree">
     <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
      <i class="fa-solid fa-scissors me-3"></i> Barberos
     </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#serviciosAccordion">
     <div class="accordion-body">
      <div class="row g-4">
       <div class="table-responsive">
        <table class="table table-dark table-striped">
         <thead>
          <tr>
           <th>ID</th>
           <th>Nombre</th>
           <th>Especialidad</th>
           <th>Estado</th>
           <th>Acciones</th>
          </tr>
         </thead>
         <tbody>
          <?php foreach ($barberos as $b): ?>
          <tr>
           <td><?= $b['id'] ?></td>
           <td colspan="3">
            <form action="" method="post" class="d-flex gap-2 align-items-center">
             <input type="hidden" name="id" value="<?= $b['id'] ?>">
             <input type="text" name="nombre" value="<?= htmlspecialchars($b['nombre']) ?>" class="form-control form-control-sm" required>
             <input type="text" name="especialidad" value="<?= htmlspecialchars($b['especialidad']) ?>" class="form-control form-control-sm" required>
             <select name="estado" class="form-select form-select-sm" required>
              <option value="activo" <?= ($b['estado'] == 'activo') ? 'selected' : '' ?>>Activo</option>
              <option value="inactivo" <?= ($b['estado'] == 'inactivo') ? 'selected' : '' ?>>Inactivo</option>
              <option value="vacaciones" <?= ($b['estado'] == 'vacaciones') ? 'selected' : '' ?>>Vacaciones</option>
             </select>
             <button type="submit" name="editar_barbero" class="btn btn-outline-primary btn-sm" title="Editar barbero">
              <i class="fa fa-pen"></i>
             </button>
             <button type="submit" name="eliminar_barbero" class="btn btn-outline-danger btn-sm" title="Eliminar barbero" onclick="return confirm('¿Eliminar barbero?');">
              <i class="fa fa-trash"></i>
             </button>
            </form>
           </td>
          </tr>
          <?php endforeach; ?>
         </tbody>
        </table>
       </div>
      </div>
      <hr class="my-5 accent">
      <h4 class="mb-3 accent">Agregar Nuevo Barbero</h4>
      <form action="" method="post" class="row g-3">
       <div class="col-md-4">
        <input type="text" name="nombre" class="form-control" placeholder="Nombre" required>
       </div>
       <div class="col-md-4">
        <input type="text" name="especialidad" class="form-control" placeholder="Especialidad" required>
       </div>
       <div class="col-md-2">
        <select name="estado" class="form-select" required>
         <option value="activo">Activo</option>
         <option value="inactivo">Inactivo</option>
         <option value="vacaciones">Vacaciones</option>
        </select>
       </div>
       <div class="col-md-2">
        <button type="submit" name="agregar_barbero" class="btn btn-success w-100">Agregar</button>
       </div>
      </form>
     </div>
    </div>
   </div>
  </div>
 </div>
</section>

<footer class="py-5" style="background-color: #1c1c1c; color: #e0e0e0;">
 <div class="container">
  <div class="row">
   <div class="col-md-4 mb-3">
    <p class="mb-1">&copy; 2025 Barbería Estilo</p>
    <a href="#" class="text-decoration-none text-secondary me-2">Privacy Policy</a>|
    <a href="#" class="text-decoration-none text-secondary mx-2">Terms of Service</a>|
    <a href="#" class="text-decoration-none text-secondary ms-2">Website Design by YourName</a>
   </div>
   <div class="col-md-4 mb-3 text-center">
    <p class="mb-2">Follow us:</p>
    <a href="https://www.instagram.com/kevin477_/" target="_blank" class="text-white me-3">
     <i class="fa-brands fa-instagram fa-lg accent"></i>
    </a>
    <a href="#" class="text-white me-3">
     <i class="fa-brands fa-facebook fa-lg accent"></i>
    </a>
    <a href="#" class="text-white">
     <i class="fa-brands fa-whatsapp fa-lg accent"></i>
    </a>
   </div>
   <div class="col-md-4 mb-3">
    <p class="mb-1"><strong>Contact:</strong></p>
    <p class="mb-1">Tel: 443-643-8903</p>
    <p class="mb-1">Email: info@barberiaestilo.com</p>
    <p class="mb-0"><strong>Hours:</strong></p>
    <p class="mb-0">Mon - Thurs: 9am - 8pm</p>
    <p class="mb-0">Fri: 9am - 8pm</p>
    <p class="mb-0">Sat: 9am - 4pm</p>
    <p class="mb-0">Sun: Closed</p>
   </div>
  </div>
  <div class="text-center mt-4">
   <a href="#top" class="btn btn-outline-light btn-sm">Back to top</a>
   </div>
 </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
 const faders = document.querySelectorAll('.fade-in');
 const appearOptions = { threshold: 0.2, rootMargin: "0px 0px -50px 0px" };
 const appearOnScroll = new IntersectionObserver((entries, observer) => {
  entries.forEach(entry => {
   if(entry.isIntersecting){
    entry.target.classList.add('visible');
    observer.unobserve(entry.target);
   }
  });
 }, appearOptions);
 faders.forEach(fader => appearOnScroll.observe(fader));

 const header = document.querySelector('header');
 window.addEventListener('scroll', () => {
 if(window.scrollY > window.innerHeight - 50){
header.classList.remove('transparent');
header.classList.add('solid');
} else {
header.classList.remove('solid');
header.classList.add('transparent');
}
 });
</script>
</body>
</html>