<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Barbería Estilo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../css/loading.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #1c1c1c;
            color: #e0e0e0;
            scroll-behavior: smooth;
             zoom: 0.6;


        }

        header {
            background: transparent !important;
            position: fixed;
            width: 100%;
            z-index: 1000;
            transition: background-color 0.3s ease;
        }

        header.transparent {
            background-color: transparent !important;
        }

        header.solid {
            background-color: #1c1c1c !important;
        }

        /* Estilos del menú replicados */
        header .container-fluid {
            padding-top: 2.5rem;
            padding-bottom: 2.5rem;
        }

        .navbar-brand.blend-logo {
            font-weight: 600;
            letter-spacing: 3px;
            font-size: 4rem;
        }

        .nav-link {
            font-size: 1.5rem;
            font-weight: 600;
            letter-spacing: 1.5px;
            color: #E0E0E0 !important;
            transition: color 0.3s ease;
            padding: 2rem 3rem !important;
        }

        .btn-book-now {
            background-color: #A38C6C;
            color: #fff;
            border: none;
            font-weight: 600;
            padding: 25px 50px;
            transition: all 0.3s ease;
            font-size: 1.4rem;
        }

        .nav-link:hover {
            color: #C7A86D !important;
        }

        .btn-book-now:hover {
            background-color: #8C7B5D;
            transform: scale(1.05);
        }

        .navbar-brand span {
            font-weight: 600;
            letter-spacing: 1px;
        }

        .btn-primary {
            background-color: #c7a86d;
            border: none;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #b08f56;
            transform: scale(1.05);
        }

        .btn-outline-light:hover {
            background-color: #f1f1f1;
            color: #000;
        }

        h1,
        h2,
        h3,
        h4 {
            font-family: inherit;
        }

        section {
            padding: 6rem 0;
        }

        #inicio {
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.85)), url('../img/one.jpg') center/cover no-repeat;
            color: white;
            text-align: center;
            min-height: 200vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }

        #inicio h1 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }

        #servicios .card,
        #comentarios .card,
        #blend-style .card {
            background-color: #2a2a2a;
            border-radius: 12px;
            padding: 2rem;
            transition: transform 0.4s ease, box-shadow 0.4s ease;
        }

        #servicios .card:hover,
        #comentarios .card:hover,
        #blend-style .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.6);
        }

        #nosotros,
        #servicios,
        #blend-style,
        #faq {
            background-color: #2a2a2a;
            color: #e0e0e0;
            border-radius: 12px;
            padding: 3rem;
        }

        #faq .accordion-item {
            background-color: #2a2a2a;
            border-radius: 12px;
            margin-bottom: 1rem;
        }

        footer {
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding: 2rem 0;
            text-align: center;
        }

        .accent {
            color: #c7a86d;
        }

        #blend-style img {
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
            width: 100%;
            height: auto;
            object-fit: cover;
        }

        .fade-in {
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 0.8s ease, transform 0.8s ease;
        }

        .fade-in.visible {
            opacity: 1;
            transform: translateY(0);
        }

        #comentarios .btn-like,
        #comentarios .btn-laugh,
        #comentarios .btn-wow {
            transition: transform 0.2s, box-shadow 0.2s;
        }

        #comentarios .btn-like:hover,
        #comentarios .btn-laugh:hover,
        #comentarios .btn-wow:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        #comentarios h2.accent {
            color: #c7a86d;
            font-weight: 700;
            letter-spacing: 1px;
        }

        /* --- Cambios en el formulario --- */
        .form-section {
            background: rgba(255, 255, 255, 0.2);
            /* Más transparente */
            backdrop-filter: blur(5px);
            /* Efecto de desenfoque */
            border-radius: 25px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            padding: 80px;
            /* Mucho más grande */
            max-width: 600px;
            /* Más ancho aún */
            width: 100%;
            color: #e0e0e0;
            /* Color del texto para el fondo transparente */
            font-family: 'Segoe UI', sans-serif;
        }

        .form-section h3,
        .form-section p,
        .form-section label {
            color: #e0e0e0;
            /* Color del texto para el fondo transparente */
        }

        .form-control {
            border-radius: 10px;
            padding: 20px;
            /* Más alto */
            font-size: 1.25rem;
            /* Aumenta el tamaño de la fuente del input */
            background-color: rgba(255, 255, 255, 0.1);
            /* Transparencia en los inputs */
            border: 1px solid rgba(255, 255, 255, 0.3);
            /* Borde claro */
            color: #fff;
            /* Texto blanco */
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
            /* Color del placeholder */
        }

        .btn-login {
            background: #c7a86d;
            border: none;
            border-radius: 10px;
            width: 100%;
            padding: 20px;
            /* Mucho más grande */
            font-size: 1.5rem;
            /* Aumenta el tamaño de la fuente del botón */
            font-weight: bold;
            color: #fff;
            transition: background 0.3s;
        }

        .btn-login:hover {
            background: #b08f56;
        }

        .forgot-link a {
            color: #c7a86d;
            text-decoration: none;
        }

        .forgot-link a:hover {
            text-decoration: underline;
        }

        .btn-outline-secondary {
            color: #e0e0e0;
            border-color: rgba(255, 255, 255, 0.3);
            background-color: rgba(255, 255, 255, 0.1);
        }

        .btn-outline-secondary:hover {
            background-color: rgba(255, 255, 255, 0.2);
            color: #fff;
        }
    </style>
    <script src="../js/validar_l.js" defer></script>
</head>

<body>

    <?php if (isset($_GET['registro']) && $_GET['registro'] === 'ok'): ?>
        <div class="alert alert-success text-center mt-4" role="alert">
            ¡Registro exitoso! Ahora puedes iniciar sesión.
        </div>
    <?php endif; ?>
    <header class="p-3 transparent">
        <div class="container-fluid d-flex flex-wrap justify-content-between align-items-center">
            <a href="#inicio" class="navbar-brand blend-logo text-white text-decoration-none ms-3">
                BLEND
            </a>
            <ul class="nav mb-2 mb-md-0 d-flex">
                <li><a href="../index.php" class="nav-link px-3 text-white">INICIO</a></li>
                <li><a href="../index.php#servicios" class="nav-link px-3 text-white"> SERVICES</a></li>
                <li><a href="#" class="nav-link px-3 text-white">COLOR SERVICES</a></li>
                <li><a href="#" class="nav-link px-3 text-white">BLOWOUTS</a></li>
                <li><a href="nosotros.php" class="nav-link px-3 text-white">PELUQUEROS</a></li>
                <li><a href="#" class="nav-link px-3 text-white">CAREERS</a></li>
                <li><a href="#" class="nav-link px-3 text-white">CONTACT</a></li>
            </ul>
            <a href="registro.php" class="btn btn-book-now me-3">
                REGISTRARSE <i class="fa-solid fa-chevron-down ms-2" style="font-size: 0.8em;"></i>
            </a>
        </div>
    </header>

    <section id="inicio" class="d-flex flex-column justify-content-center align-items-center text-center fade-in">
        <p class="lead mb-4">Certified Invisible Bead Extensions® Stylists and Colorists in Baltimore, MD | Blend Salon
        </p>
        <br><br>
        <main>
            <div class="container main-content-wrapper">
                <div class="row g-5 align-items-center justify-content-center w-100">

                    <div
                        class="col-lg-6 d-flex flex-column align-items-center align-items-lg-start text-center text-lg-start">
                        <div class="benefits">
                            <div
                                class="d-flex align-items-center mb-4 logo justify-content-center justify-content-lg-start">
                                <i class="fa-solid fa-scissors fa-2x accent me-2"></i>
                                <span class="fs-4">Barbería Estilo</span>
                            </div>
                            <ul class="list-unstyled fs-5">
                                <li><i class="fa-solid fa-check-circle me-2 accent"></i>Reservá turnos para vos y tu
                                    familia.</li>
                                <li><i class="fa-solid fa-check-circle me-2 accent"></i>Consultá y descargá tu historial
                                    de servicios.</li>
                                <li><i class="fa-solid fa-check-circle me-2 accent"></i>Atención con barberos
                                    profesionales.</li>
                                <li><i class="fa-solid fa-check-circle me-2 accent"></i>Más de 10 años de experiencia.
                                </li>
                                <li><i class="fa-solid fa-check-circle me-2 accent"></i>Soporte 24hs vía WhatsApp o
                                    chat.</li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-6 d-flex justify-content-center">
                        <div class="form-section">
                            <h3>¡Hola!</h3>
                            <p>Iniciá sesión o <a href="registro.php" class="accent text-decoration-none">creá una
                                    cuenta</a></p>



                            <form id="form-login" action="log.php" method="post">
                                <div class="mb-3">
                                    <label for="email" class="form-label fs-5" style="color: #e0e0e0;">Correo
                                        electrónico</label>
                                    <input type="email" class="form-control" placeholder="correo@mail.com" name="email"
                                        id="email" required>
                                </div>
                                <div class="mb-1">
                                    <label for="clave" class="form-label fs-5"
                                        style="color: #e0e0e0;">Contraseña</label>
                                    <div class="input-group">
                                        <input type="password" class="form-control" placeholder="••••••••" name="clave"
                                            id="clave" required>
                                        <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                            <i class="fa-solid fa-eye" id="eyeIcon"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="forgot-link">
                                    <a href="#" class="accent">Olvidé mi contraseña</a>
                                </div>
                                <div class="mt-4">
                                    <button type="submit" class="btn btn-login w-100 btn-lg fw-bold">Ingresar al
                                        Portal</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </section>




    <footer class="py-5" style="background-color: #1c1c1c; color: #e0e0e0;">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <p class="mb-1">&copy; 2025 Barbería Estilo</p>
                    <a href="#" class="text-decoration-none text-secondary me-2">Privacy Policy</a>|
                    <a href="#" class="text-decoration-none text-secondary mx-2">Terms of Service</a>|
                    <a href="#" class="text-decoration-none text-secondary ms-2">Website Design by YourName</a>
                </div>
                <div class="col-md-4 mb-3 text-center">
                    <p class="mb-2">Follow us:</p>
                    <a href="https://www.instagram.com/kevin477_/" target="_blank" class="text-white me-3">
                        <i class="fa-brands fa-instagram fa-lg accent"></i>
                    </a>
                    <a href="#" class="text-white me-3">
                        <i class="fa-brands fa-facebook fa-lg accent"></i>
                    </a>
                    <a href="#" class="text-white">
                        <i class="fa-brands fa-whatsapp fa-lg accent"></i>
                    </a>
                </div>
                <div class="col-md-4 mb-3">
                    <p class="mb-1"><strong>Contact:</strong></p>
                    <p class="mb-1">Tel: 443-643-8903</p>
                    <p class="mb-1">Email: info@barberiaestilo.com</p>
                    <p class="mb-0"><strong>Hours:</strong></p>
                    <p class="mb-0">Mon - Thurs: 9am - 8pm</p>
                    <p class="mb-0">Fri: 9am - 8pm</p>
                    <p class="mb-0">Sat: 9am - 4pm</p>
                    <p class="mb-0">Sun: Closed</p>
                </div>
            </div>
            <div class="text-center mt-4">
                <a href="#inicio" class="btn btn-outline-light btn-sm">Back to top</a>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/loading.js"></script>
    <script>
        const faders = document.querySelectorAll('.fade-in');
        const appearOptions = { threshold: 0.2, rootMargin: "0px 0px -50px 0px" };
        const appearOnScroll = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    observer.unobserve(entry.target);
                }
            });
        }, appearOptions);
        faders.forEach(fader => appearOnScroll.observe(fader));

        const header = document.querySelector('header');
        const inicio = document.querySelector('#inicio');
        window.addEventListener('scroll', () => {
            const inicioHeight = inicio.offsetHeight;
           if(window.scrollY > window.innerHeight - 50){
   header.classList.remove('transparent');
   header.classList.add('solid');
} else {
   header.classList.remove('solid');
   header.classList.add('transparent');
}

        });

        // La lógica para mostrar/ocultar la contraseña está aquí
        document.getElementById('togglePassword').addEventListener('click', function (e) {
            e.preventDefault();
            const input = document.getElementById('clave');
            const icon = document.getElementById('eyeIcon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });

        // Sistema de loading para el formulario de login
        handleFormWithLoading('form-login', 'login', 'Iniciando sesión...');
    </script>
</body>

</html>