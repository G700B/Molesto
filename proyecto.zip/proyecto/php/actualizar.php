<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$id_turno = isset($_POST['turno_id']) ? intval($_POST['turno_id']) : 0;

if ($id_turno <= 0) {
    die("Turno no válido.");
}

// Campos del primer turno
$fecha = $_POST['fecha_turno'];
$hora = $_POST['hora_turno'];
$servicio = intval($_POST['servicio']);
$descripcion = $_POST['descripcion'];
$barbero = ($_POST['barbero'] !== '') ? intval($_POST['barbero']) : null;
$whatsapp = isset($_POST['whatsapp_confirm']) ? 1 : 0;
$metodo_pago = isset($_POST['metodo_pago']) ? intval($_POST['metodo_pago']) : 0;

// Campos del segundo turno
$fecha2 = $_POST['fecha_turno_2'] ?? null;
$hora2 = $_POST['hora_turno_2'] ?? null;
$servicio2 = isset($_POST['servicio_2']) && $_POST['servicio_2'] !== '' ? intval($_POST['servicio_2']) : null;

// Validar método de pago
if ($metodo_pago <= 0) {
    die("Método de pago inválido.");
}

$sql_check = "SELECT COUNT(*) FROM metodos_pago WHERE id = ?";
$stmt_check = $con->prepare($sql_check);
$stmt_check->bind_param("i", $metodo_pago);
$stmt_check->execute();
$stmt_check->bind_result($count);
$stmt_check->fetch();
$stmt_check->close();

if ($count == 0) {
    die("El método de pago seleccionado no existe.");
}

// Si la hora del primer turno es distinta a la del segundo, borrar segundo turno
if ($hora !== $hora2) {
    $fecha2 = null;
    $hora2 = null;
    $servicio2 = null;
}

// Actualizar turno
$sql = "UPDATE turnos 
        SET fecha = ?, hora = ?, servicio = ?, descripcion = ?, barbero = ?, whatsapp = ?, metodo_pago = ?,
            fecha_turno_2 = ?, hora_turno_2 = ?, servicio_2 = ?
        WHERE id = ? AND usuario_id = ?";

$stmt = $con->prepare($sql);
$stmt->bind_param(
    "ssississsiii",
    $fecha, 
    $hora, 
    $servicio, 
    $descripcion, 
    $barbero, 
    $whatsapp, 
    $metodo_pago, 
    $fecha2, 
    $hora2, 
    $servicio2, 
    $id_turno, 
    $usuario_id
);

if (!$stmt->execute()) {
    die("Error al ejecutar la actualización: " . $stmt->error);
}

if ($stmt->affected_rows > 0) {
    header("Location: ver_turno.php?msg=editado");
    exit();
} else {
    echo "No se pudo actualizar el turno o no hubo cambios.";
}

$stmt->close();
$con->close();
?>
