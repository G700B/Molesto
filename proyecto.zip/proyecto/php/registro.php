<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">

<head>
  <meta charset="UTF-8" />
  <title>Registro - Barbería Estilo</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link rel="stylesheet" href="../css/loading.css" />
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #1c1c1c;
      color: #e0e0e0;
      min-height: 100vh;
      scroll-behavior: smooth;
      zoom: 0.6;
    }

    header {
      background: transparent !important;
      position: fixed;
      width: 100%;
      z-index: 1000;
      transition: background-color 0.3s ease;
    }

    header.transparent {
      background-color: transparent !important;
    }

    header.solid {
      background-color: #1c1c1c !important;
    }

    /* Estilos del menú replicados */
    header .container-fluid {
      padding-top: 2.5rem;
      padding-bottom: 2.5rem;
    }

    .navbar-brand.blend-logo {
      font-weight: 600;
      letter-spacing: 3px;
      font-size: 4rem;
    }

    .nav-link {
      font-size: 1.5rem;
      font-weight: 600;
      letter-spacing: 1.5px;
      color: #E0E0E0 !important;
      transition: color 0.3s ease;
      padding: 2rem 3rem !important;
    }

    .btn-book-now {
      background-color: #A38C6C;
      color: #fff;
      border: none;
      font-weight: 600;
      padding: 25px 50px;
      transition: all 0.3s ease;
      font-size: 1.4rem;
    }

    .nav-link:hover {
      color: #C7A86D !important;
    }

    .btn-book-now:hover {
      background-color: #8C7B5D;
      transform: scale(1.05);
    }

    .accent {
      color: #c7a86d;
    }

    h1,
    h2,
    h3,
    h4 {
      font-family: inherit;
    }

    .form-section {
      background: rgba(255, 255, 255, 0.2);
      backdrop-filter: blur(5px);
      border-radius: 25px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
      padding: 80px;
      max-width: 600px;
      width: 100%;
      color: #e0e0e0;
      font-family: 'Segoe UI', sans-serif;
    }

    .form-section h3,
    .form-section p,
    .form-section label {
      color: #e0e0e0;
    }

    .form-control {
      border-radius: 10px;
      padding: 20px;
      font-size: 1.25rem;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: #fff;
    }

    .form-control::placeholder {
      color: rgba(255, 255, 255, 0.7);
    }

    .btn-login {
      background: #c7a86d;
      border: none;
      border-radius: 10px;
      width: 100%;
      padding: 20px;
      font-size: 1.5rem;
      font-weight: bold;
      color: #fff;
      transition: background 0.3s;
    }

    .btn-login:hover {
      background: #b08f56;
    }

    .forgot-link a {
      color: #c7a86d;
      text-decoration: none;
    }

    .forgot-link a:hover {
      text-decoration: underline;
    }

    .btn-register {
      background: #c7a86d;
      border: none;
      border-radius: 10px;
      width: 100%;
      padding: 20px;
      font-size: 1.5rem;
      font-weight: bold;
      color: #fff;
      transition: background 0.3s;
    }

    .btn-register:hover {
      background: #b08f56;
    }
  </style>
  <script src="../js/validar_r.js" defer></script>
</head>

<body>

  <header class="p-3 transparent">
    <div class="container-fluid d-flex flex-wrap justify-content-between align-items-center">
      <a href="../index.html" class="navbar-brand blend-logo text-white text-decoration-none ms-3">
        BLEND
      </a>
      <ul class="nav mb-2 mb-md-0 d-flex">
        <li><a href="../index.php" class="nav-link px-3 text-white">INICIO</a></li>
        <li><a href="../index.php#servicios" class="nav-link px-3 text-white">SERVICES</a></li>
        <li><a href="#" class="nav-link px-3 text-white">COLOR SERVICES</a></li>
        <li><a href="#" class="nav-link px-3 text-white">BLOWOUTS</a></li>
        <li><a href="nosotros.php" class="nav-link px-3 text-white">PELUQUEROS</a></li>
        <li><a href="#" class="nav-link px-3 text-white">CAREERS</a></li>
        <li><a href="#" class="nav-link px-3 text-white">CONTACT</a></li>
      </ul>
      <a href="login.php" class="btn btn-book-now me-3">
        LOGIN <i class="fa-solid fa-chevron-down ms-2" style="font-size: 0.8em;"></i>
      </a>
    </div>
  </header>

  <section id="inicio" class="d-flex flex-column justify-content-center align-items-center text-center fade-in"
    style="background: linear-gradient(to bottom, rgba(0,0,0,0.5), rgba(0,0,0,0.85)), url('../img/one.jpg') center/cover no-repeat; min-height: 100vh; color: white;">
    <br><br><br><br><br><br><br><br><br><br><br><br>
    <p class="lead mb-4">Certified Invisible Bead Extensions® Stylists and Colorists in Baltimore, MD | Blend Salon</p>
    <br><br>
    <?php if (isset($_GET['error'])): ?>
      <div class="alert alert-danger text-center mt-4" role="alert">
        <?php
        if ($_GET['error'] === 'existe') {
          echo 'Este correo ya está registrado.';
        } elseif ($_GET['error'] === '1') {
          echo 'Error al registrar. Intenta nuevamente.';
        } else {
          echo 'Acceso no permitido.';
        }
        ?>
      </div>
    <?php endif; ?>
    <main class="d-flex align-items-center justify-content-center w-100">
      <div class="container d-flex flex-column flex-md-row align-items-center justify-content-center gap-5">

        <div class="benefits">
          <div class="d-flex align-items-center mb-4 logo justify-content-center justify-content-lg-start">
            <i class="fa-solid fa-scissors fa-2x accent me-2"></i>
            <span class="fs-4">Barbería Estilo</span>
          </div>
          <ul class="list-unstyled fs-5">
            <li><i class="fa-solid fa-check-circle me-2 accent"></i>Registrate en segundos.</li>
            <li><i class="fa-solid fa-check-circle me-2 accent"></i>Reservá turnos desde tu cuenta.</li>
            <li><i class="fa-solid fa-check-circle me-2 accent"></i>Historial y soporte personalizado.</li>
            <li><i class="fa-solid fa-check-circle me-2 accent"></i>10 años de experiencia.</li>
          </ul>
        </div>

        <div class="form-section">
          <h3>Crear cuenta</h3>
          <p>Ingresa tus datos para registrarte.</p>

          <form action="registros.php" method="POST" id="registroForm" novalidate>
            <div class="mb-3">
              <label for="nombre" class="form-label fs-5">Nombre</label>
              <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Juan" required>
            </div>
            <div class="mb-3">
              <label for="apellido" class="form-label fs-5">Apellido</label>
              <input type="text" class="form-control" id="apellido" name="apellido" placeholder="Pérez" required>
            </div>
            <div class="mb-3">
              <label for="fecha_nac" class="form-label fs-5">Fecha de nacimiento</label>
              <input type="date" class="form-control" id="fecha_nac" name="fecha_nac" required>
            </div>
            <div class="mb-3">
              <label for="telefono" class="form-label fs-5">Teléfono</label>
              <input type="tel" class="form-control" id="telefono" name="telefono" placeholder="11 2345-6789" required>
            </div>
            <div class="mb-3">
              <label for="email" class="form-label fs-5">Correo electrónico</label>
              <input type="email" class="form-control" id="email" name="email" placeholder="correo@mail.com" required>
            </div>
            <div class="mb-4">
              <label for="clave" class="form-label fs-5">Contraseña</label>
              <input type="password" class="form-control" id="clave" name="clave" placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn btn-register w-100 btn-lg fw-bold">Registrarme</button>
          </form>
          <p class="mt-3 text-center">¿Ya tenés cuenta? <a href="login.php" class="accent text-decoration-none">Iniciá
              sesión</a></p>
        </div>
      </div>
    </main>
    <br><br>
  </section>

  <footer class="py-5" style="background-color: #1c1c1c; color: #e0e0e0;">
    <div class="container">
      <div class="row">
        <div class="col-md-4 mb-3">
          <p class="mb-1">&copy; 2025 Barbería Estilo</p>
          <a href="#" class="text-decoration-none text-secondary me-2">Privacy Policy</a>|
          <a href="#" class="text-decoration-none text-secondary mx-2">Terms of Service</a>|
          <a href="#" class="text-decoration-none text-secondary ms-2">Website Design by YourName</a>
        </div>
        <div class="col-md-4 mb-3 text-center">
          <p class="mb-2">Follow us:</p>
          <a href="https://www.instagram.com/kevin477_/" target="_blank" class="text-white me-3">
            <i class="fa-brands fa-instagram fa-lg accent"></i>
          </a>
          <a href="#" class="text-white me-3">
            <i class="fa-brands fa-facebook fa-lg accent"></i>
          </a>
          <a href="#" class="text-white">
            <i class="fa-brands fa-whatsapp fa-lg accent"></i>
          </a>
        </div>
        <div class="col-md-4 mb-3">
          <p class="mb-1"><strong>Contact:</strong></p>
          <p class="mb-1">Tel: 443-643-8903</p>
          <p class="mb-1">Email: info@barberiaestilo.com</p>
          <p class="mb-0"><strong>Hours:</strong></p>
          <p class="mb-0">Mon - Thurs: 9am - 8pm</p>
          <p class="mb-0">Fri: 9am - 8pm</p>
          <p class="mb-0">Sat: 9am - 4pm</p>
          <p class="mb-0">Sun: Closed</p>
        </div>
      </div>
      <div class="text-center mt-4">
        <a href="#inicio" class="btn btn-outline-light btn-sm">Back to top</a>
      </div>
    </div>
  </footer>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../js/loading.js"></script>
  <script>
    // Sistema de loading para el formulario de registro
    handleFormWithLoading('registroForm', 'register', 'Creando tu cuenta...');
  </script>
</body>

</html>