<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];

$sql = "SELECT t.*, 
                s.nombre AS servicio_nombre, 
                b.nombre AS barbero_nombre,
                s2.nombre AS servicio2_nombre
        FROM turnos t
        INNER JOIN servicios s ON s.id = t.servicio
        LEFT JOIN barberos b ON b.id = t.barbero
        LEFT JOIN servicios s2 ON s2.id = t.servicio_2
        WHERE t.usuario_id = ?
        ORDER BY t.fecha DESC, t.hora DESC";

$stmt = $con->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$resultado = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Historial de Turnos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #1c1c1c;
            color: #e0e0e0;
            scroll-behavior: smooth;
            zoom: 0.6;
        }
        header {
            background: transparent !important;
            position: fixed;
            width: 100%;
            z-index: 1000;
            transition: background-color 0.3s ease;
        }
        header.transparent {
            background-color: transparent !important;
        }
        header.solid {
            background-color: #1c1c1c !important;
        }

        /* Estilos del menú replicados */
        header .container-fluid {
            padding-top: 2.5rem;
            padding-bottom: 2.5rem;
        }
        .navbar-brand.blend-logo {
            font-weight: 600;
            letter-spacing: 3px;
            font-size: 4rem;
        }
        .nav-link {
            font-size: 1.5rem;
            font-weight: 600;
            letter-spacing: 1.5px;
            color: #E0E0E0 !important;
            transition: color 0.3s ease;
            padding: 2rem 3rem !important;
        }
        .btn-book-now {
            background-color: #A38C6C;
            color: #fff;
            border: none;
            font-weight: 600;
            padding: 25px 50px;
            transition: all 0.3s ease;
            font-size: 1.4rem;
        }
        .nav-link:hover {
            color: #C7A86D !important;
        }
        .btn-book-now:hover {
            background-color: #8C7B5D;
            transform: scale(1.05);
        }

        .navbar-brand span {
            font-weight: 600;
            letter-spacing: 1px;
        }
        .btn-primary {
            background-color: #c7a86d;
            border: none;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #b08f56;
            transform: scale(1.05);
        }
        .btn-outline-light:hover {
            background-color: #f1f1f1;
            color: #000;
        }
        h1, h2, h3, h4 {
            font-family: inherit;
        }
        section {
            padding: 6rem 0;
        }
        #inicio {
            background: linear-gradient(to bottom, rgba(0,0,0,0.5), rgba(0,0,0,0.85)), url('../img/one.jpg') center/cover no-repeat;
            color: white;
            text-align: center;
            min-height: 200vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }
        #inicio h1 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }
        #servicios .card, #comentarios .card, #blend-style .card {
            background-color: #2a2a2a;
            border-radius: 12px;
            padding: 2rem;
            transition: transform 0.4s ease, box-shadow 0.4s ease;
        }
        #servicios .card:hover, #comentarios .card:hover, #blend-style .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 12px 25px rgba(0,0,0,0.6);
        }
        #nosotros, #servicios, #blend-style, #faq {
            background-color: #2a2a2a;
            color: #e0e0e0;
            border-radius: 12px;
            padding: 3rem;
        }
        #faq .accordion-item {
            background-color: #2a2a2a;
            border-radius: 12px;
            margin-bottom: 1rem;
        }
        footer {
            border-top: 1px solid rgba(255,255,255,0.1);
            padding: 2rem 0;
            text-align: center;
        }
        .accent {
            color: #c7a86d;
        }
        #blend-style img {
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.5);
            width: 100%;
            height: auto;
            object-fit: cover;
        }
        .fade-in {
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 0.8s ease, transform 0.8s ease;
        }
        .fade-in.visible {
            opacity: 1;
            transform: translateY(0);
        }
        #comentarios .btn-like,
        #comentarios .btn-laugh,
        #comentarios .btn-wow {
            transition: transform 0.2s, box-shadow 0.2s;
        }
        #comentarios .btn-like:hover,
        #comentarios .btn-laugh:hover,
        #comentarios .btn-wow:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }
        #comentarios h2.accent {
            color: #c7a86d;
            font-weight: 700;
            letter-spacing: 1px;
        }

        /* --- Estilos para la tabla o cards del historial --- */
        .card-turno {
            background-color: #2a2a2a;
            border-radius: 12px;
            padding: 2rem;
            transition: transform 0.4s ease, box-shadow 0.4s ease;
            height: 100%;
        }
        .card-turno:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.4);
        }
        .card-turno h5 {
            font-weight: 600;
            margin-bottom: 1rem;
            color: #c7a86d;
        }
        .card-turno p {
            font-size: 1rem;
            margin-bottom: 0.5rem;
        }
        .alert-warning {
            background-color: #403628;
            border-color: #7a6649;
            color: #e0e0e0;
        }
    </style>
</head>
<body>
<header class="p-3 transparent">
    <div class="container-fluid d-flex flex-wrap justify-content-between align-items-center">
        <a href="#inicio" class="navbar-brand blend-logo text-white text-decoration-none ms-3">
            BLEND
        </a>
        <ul class="nav mb-2 mb-md-0 d-flex">
            <li><a href="index2.php" class="nav-link px-3 text-white">INICIO</a></li>
            <li><a href="ver_turno.php" class="nav-link px-3 text-white">VER TURNO</a></li>
            <li><a href="historial.php" class="nav-link px-3 accent">HISTORIAL</a></li>
            <li><a href="tienda2.php" class="nav-link px-3 text-white">TIENDA</a></li>
            <li><a href="historial_compras.php" class="nav-link px-3 text-white">HISTORIAL COMPRAS</a></li>
        </ul>
        <div class="text-end d-flex align-items-center gap-3 me-3">
            <a href="carrito.php" class="btn btn-outline-light position-relative me-2">
                <i class="fa-solid fa-cart-shopping"></i>
            </a>
            <?php if (isset($_SESSION['usuario_nombre'])): ?>
                <div class="dropdown">
                    <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="fa-solid fa-user"></i> <?= htmlspecialchars($_SESSION['usuario_nombre']) ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar sesión</a></li>
                    </ul>
                </div>
            <?php else: ?>
                <a href="login.php"><button class="btn btn-primary me-2">LOGIN</button></a>
                <a href="registro.php"><button class="btn btn-book-now">REGISTRARSE</button></a>
            <?php endif; ?>
        </div>
    </div>
</header>

<section id="inicio" class="d-flex flex-column justify-content-center align-items-center text-center fade-in">

<main class="container pt-5 mt-5 fade-in">
    <h2 class="text-center fw-bold my-5 accent">
        <i class="fa fa-history me-3"></i>Historial de Turnos
    </h2>

    <div class="row g-4 justify-content-center">
        <?php if ($resultado->num_rows > 0): ?>
            <?php while ($row = $resultado->fetch_assoc()): ?>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card-turno" style="border-radius: 15px; background-color: rgba(255,255,255,0.8); color:black;">
                        <h5 >
                            <i style="background-color: #87d5ffff; color: #000;" class="fa fa-calendar-days me-2" ></i><?= htmlspecialchars($row['fecha']) ?> - <?= htmlspecialchars($row['hora']) ?>
                        </h5>
                        <p><strong>Servicio:</strong> <?= htmlspecialchars($row['servicio_nombre']) ?></p>

                        <?php if (!empty($row['fecha_turno_2']) && !empty($row['hora_turno_2']) && !empty($row['servicio2_nombre'])): ?>
                            <hr style="border-color: rgba(255,255,255,0.1);">
                            <p class="mb-1"><strong>Segundo turno:</strong></p>
                            <p><i class="fa fa-calendar me-2"></i><?= htmlspecialchars($row['fecha_turno_2']) ?> - <?= htmlspecialchars($row['hora_turno_2']) ?></p>
                            <p><strong>Servicio:</strong> <?= htmlspecialchars($row['servicio2_nombre']) ?></p>
                        <?php endif; ?>

                        <p><strong>Barbero:</strong> <?= htmlspecialchars($row['barbero_nombre'] ?: 'Cualquiera') ?></p>
                        <p>
                            <strong>Estado:</strong>
                            <?php if ($row['estado'] === 'cancelado'): ?>
                                <span class="badge bg-danger">Cancelado</span>
                            <?php else: ?>
                                <span class="badge bg-success">Activo</span>
                            <?php endif; ?>
                        </p>
                        <?php if ($row['estado'] === 'cancelado' && !empty($row['cancelacion_motivo'])): ?>
                            <p class="text-danger fw-bold mb-0"><strong>Motivo:</strong> <?= htmlspecialchars($row['cancelacion_motivo']) ?></p>
                        <?php endif; ?>
                        <a style="background-color: #ffec8bff; color: #000;" href="../pdf/tutorial/tuto2.php?turno_id=<?= $row['id'] ?>" target="_blank" class="btn btn-primary w-100 mt-2">
                            <i class="fa fa-file-pdf me-2"></i>Ver Comprobante
                        </a>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-warning text-center shadow-sm border border-warning border-2 rounded">
                    <i class="fa fa-info-circle me-2"></i>No tenés turnos registrados.
                </div>
            </div>
        <?php endif; ?>
    </div>
</main>
  </section>


<footer class="py-5" style="background-color: #1c1c1c; color: #e0e0e0;">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-3">
                <p class="mb-1">&copy; 2025 Barbería Estilo</p>
                <a href="#" class="text-decoration-none text-secondary me-2">Privacy Policy</a>|
                <a href="#" class="text-decoration-none text-secondary mx-2">Terms of Service</a>|
                <a href="#" class="text-decoration-none text-secondary ms-2">Website Design by YourName</a>
            </div>
            <div class="col-md-4 mb-3 text-center">
                <p class="mb-2">Follow us:</p>
                <a href="https://www.instagram.com/kevin477_/" target="_blank" class="text-white me-3">
                    <i class="fa-brands fa-instagram fa-lg accent"></i>
                </a>
                <a href="#" class="text-white me-3">
                    <i class="fa-brands fa-facebook fa-lg accent"></i>
                </a>
                <a href="#" class="text-white">
                    <i class="fa-brands fa-whatsapp fa-lg accent"></i>
                </a>
            </div>
            <div class="col-md-4 mb-3">
                <p class="mb-1"><strong>Contact:</strong></p>
                <p class="mb-1">Tel: 443-643-8903</p>
                <p class="mb-1">Email: info@barberiaestilo.com</p>
                <p class="mb-0"><strong>Hours:</strong></p>
                <p class="mb-0">Mon - Thurs: 9am - 8pm</p>
                <p class="mb-0">Fri: 9am - 8pm</p>
                <p class="mb-0">Sat: 9am - 4pm</p>
                <p class="mb-0">Sun: Closed</p>
            </div>
        </div>
        <div class="text-center mt-4">
            <a href="#top" class="btn btn-outline-light btn-sm">Back to top</a>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const faders = document.querySelectorAll('.fade-in');
    const appearOptions = { threshold: 0.2, rootMargin: "0px 0px -50px 0px" };
    const appearOnScroll = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if(entry.isIntersecting){
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, appearOptions);
    faders.forEach(fader => appearOnScroll.observe(fader));

    const header = document.querySelector('header');
    const mainContent = document.querySelector('main');
    window.addEventListener('scroll', () => {
      if(window.scrollY > window.innerHeight - 50){
   header.classList.remove('transparent');
   header.classList.add('solid');
} else {
   header.classList.remove('solid');
   header.classList.add('transparent');
}

    });
</script>
</body>
</html>