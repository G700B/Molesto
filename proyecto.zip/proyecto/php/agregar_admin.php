<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$error = '';
$success = '';

// Eliminar administrador
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['eliminar_admin_id'])) {
    $admin_id = intval($_POST['eliminar_admin_id']);
 
    if ($admin_id === intval($_SESSION['usuario_id'])) {
        $error = "No puedes eliminarte a ti mismo.";
    } else {
        $stmt_del = $con->prepare("DELETE FROM usuarios WHERE id = ? AND rol = 'admin'");
        $stmt_del->bind_param("i", $admin_id);
        if ($stmt_del->execute()) {
            $success = "Administrador eliminado con éxito.";
        } else {
            $error = "Error al eliminar el administrador.";
        }
        $stmt_del->close();
    }
}

// Crear administrador
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nombre'], $_POST['email'], $_POST['clave'], $_POST['clave_confirm'])) {
    $nombre = trim($_POST['nombre']);
    $email = trim($_POST['email']);
    $clave = $_POST['clave'];
    $clave_confirm = $_POST['clave_confirm'];

    if (!$nombre || !$email || !$clave || !$clave_confirm) {
        $error = "Todos los campos son obligatorios.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "El correo no es válido.";
    } elseif ($clave !== $clave_confirm) {
        $error = "Las contraseñas no coinciden.";
    } else {
        $stmt_check = $con->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt_check->bind_param("s", $email);
        $stmt_check->execute();
        $stmt_check->store_result();

        if ($stmt_check->num_rows > 0) {
            $error = "El correo ya está registrado.";
        } else {
            $hash = password_hash($clave, PASSWORD_DEFAULT);
            $rol = 'admin';

            $stmt_insert = $con->prepare("INSERT INTO usuarios (nombre, email, pass, rol) VALUES (?, ?, ?, ?)");
            $stmt_insert->bind_param("ssss", $nombre, $email, $hash, $rol);
            if ($stmt_insert->execute()) {
                $success = "Administrador creado con éxito.";
            } else {
                $error = "Error al crear el administrador.";
            }
            $stmt_insert->close();
        }
        $stmt_check->close();
    }
}

// Obtener todos los administradores
$sql_admins = "SELECT id, nombre, email FROM usuarios WHERE rol = 'admin' ORDER BY nombre ASC";
$result_admins = $con->query($sql_admins);
$admins = $result_admins ? $result_admins->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">
<head>
    <meta charset="UTF-8" />
    <title>Agregar Admin - Panel Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #1c1c1c;
            color: #e0e0e0;
            scroll-behavior: smooth;
              zoom: 0.6;
        }
        header {
            background: transparent !important;
            position: fixed;
            width: 100%;
            z-index: 1000;
            transition: background-color 0.3s ease;
        }
        header.transparent {
            background-color: transparent !important;
        }
        header.solid {
            background-color: #1c1c1c !important;
        }

        /* Estilos del menú replicados */
        header .container-fluid {
            padding-top: 2.5rem;
            padding-bottom: 2.5rem;
        }
        .navbar-brand.blend-logo {
            font-weight: 600;
            letter-spacing: 3px;
            font-size: 4rem;
        }
        .nav-link {
            font-size: 1.5rem;
            font-weight: 600;
            letter-spacing: 1.5px;
            color: #E0E0E0 !important;
            transition: color 0.3s ease;
            padding: 2rem 3rem !important;
        }
        .btn-book-now {
            background-color: #A38C6C;
            color: #fff;
            border: none;
            font-weight: 600;
            padding: 25px 50px;
            transition: all 0.3s ease;
            font-size: 1.4rem;
        }
        .nav-link:hover {
            color: #C7A86D !important;
        }
        .btn-book-now:hover {
            background-color: #8C7B5D;
            transform: scale(1.05);
        }

        .navbar-brand span {
            font-weight: 600;
            letter-spacing: 1px;
        }
        .btn-primary {
            background-color: #c7a86d;
            border: none;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #b08f56;
            transform: scale(1.05);
        }
        .btn-outline-light:hover {
            background-color: #f1f1f1;
            color: #000;
        }
        h1, h2, h3, h4 {
            font-family: inherit;
        }
        section {
            padding: 6rem 0;
        }
        .accent {
            color: #c7a86d;
        }
        .fade-in {
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 0.8s ease, transform 0.8s ease;
        }
        .fade-in.visible {
            opacity: 1;
            transform: translateY(0);
        }
        
        /* Estilos específicos para el panel de admin */
        #inicio {
            background: linear-gradient(to bottom, rgba(0,0,0,0.5), rgba(0,0,0,0.85)), url('../img/one.jpg') center/cover no-repeat;
            color: white;
            text-align: center;
            min-height: 200vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }
        .main-container {
            padding-top: 15rem; 
            padding-bottom: 2rem;
        }
        .card-admin {
            background: rgba(42, 42, 42, 0.9);
            color: #e0e0e0;
            border-radius: 12px;
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.4);
            padding: 1.5rem;
            transition: box-shadow 0.3s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .card-admin:hover {
            box-shadow: 0 1rem 2rem rgba(0,0,0,0.6);
        }
        .admin-icon {
            font-size: 2.5rem;
            color: #c7a86d;
        }
        .admin-name {
            font-weight: 600;
            font-size: 1.25rem;
            margin-bottom: 0.25rem;
        }
        .admin-email {
            font-size: 0.875rem;
            color: #adb5bd;
        }
        form#new-admin-form {
            max-width: 420px;
            margin: 2rem auto;
            padding: 1.5rem;
            background: rgba(42, 42, 42, 0.9);
            border-radius: 12px;
            color: #f8f9fa;
            box-shadow: 0 0.25rem 0.5rem rgba(0,0,0,0.7);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .btn-info {
            background-color: #c7a86d;
            border-color: #c7a86d;
            color: #fff;
            transition: all 0.3s ease;
        }
        .btn-info:hover {
            background-color: #b08f56;
            border-color: #a07d4b;
        }
        .btn-outline-danger {
            border-color: #dc3545;
            color: #dc3545;
        }
        .btn-outline-danger:hover {
            background-color: #dc3545;
            color: #fff;
        }
        .alert-success {
            background-color: #28a745;
            border-color: #28a745;
            color: #fff;
        }
        .alert-warning {
            background-color: #ffc107;
            border-color: #ffc107;
            color: #000;
        }
        .alert-danger {
            background-color: #dc3545;
            border-color: #dc3545;
            color: #fff;
        }
    </style>
</head>
<body>

<header class="p-3 transparent">
    <div class="container-fluid d-flex flex-wrap justify-content-between align-items-center">
        <a href="panel_admin.php" class="navbar-brand blend-logo text-white text-decoration-none ms-3">
            BLEND
        </a>
        <ul class="nav mb-2 mb-md-0 d-flex">
            <li><a href="panel_admin.php" class="nav-link px-3 text-white">PANEL</a></li>
            <li><a href="agregar_admin.php" class="nav-link px-3 accent">AGREGAR ADMIN</a></li>
            <li><a href="historial_admin.php" class="nav-link px-3 text-white">HISTORIAL</a></li>
            <li><a href="servicio_admin.php" class="nav-link px-3 text-white">SERVICIOS</a></li>
        </ul>
        <div class="text-end d-flex align-items-center gap-3 me-3">
            <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <i class="fa-solid fa-user-shield"></i> <?= htmlspecialchars($_SESSION['usuario_nombre']) ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar sesión</a></li>
                </ul>
            </div>
        </div>
    </div>
</header>

<section id="inicio" class="d-flex flex-column justify-content-center align-items-center text-center fade-in">
    <div class="container main-container">
        <h2 class="text-center fw-bold my-4 accent">
            <i class="fa fa-user-plus me-3"></i>Agregar Nuevo Administrador
        </h2>

        <?php if ($error): ?>
            <div class="alert alert-danger text-center shadow-sm border border-danger border-2 rounded"><?= htmlspecialchars($error) ?></div>
        <?php elseif ($success): ?>
            <div class="alert alert-success text-center shadow-sm border border-success border-2 rounded"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form id="new-admin-form" action="agregar_admin.php" method="POST" class="text-light" style="border-radius: 15px; background-color: rgba(255,255,255,0.8); color:black;">
            <div class="mb-3">
                <label for="nombre" class="form-label" style="color:black;">Nombre</label>
                <input type="text" name="nombre" id="nombre" class="form-control" required value="<?= isset($_POST['nombre']) ? htmlspecialchars($_POST['nombre']) : '' ?>" />
            </div>
            <div class="mb-3">
                <label for="email" class="form-label" style="color:black;">Correo electrónico</label>
                <input type="email" name="email" id="email" class="form-control" required value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>" />
            </div>
            <div class="mb-3">
                <label for="clave" class="form-label" style="color:black;">Contraseña</label>
                <input type="password" name="clave" id="clave" class="form-control" required />
            </div>
            <div class="mb-3" >
                <label for="clave_confirm" class="form-label" style="color:black;">Confirmar Contraseña</label>
                <input type="password" name="clave_confirm" id="clave_confirm" class="form-control" required />
            </div>
            <button type="submit" class="btn btn-info w-100 shadow-sm rounded">
                <i class="fa fa-save me-2"></i>Crear Administrador
            </button>
        </form>

        <section class="mt-5">
            <h3 class="mb-4 text-center accent"><i class="fa fa-users me-2"></i>Administradores Registrados</h3>

            <?php if (empty($admins)): ?>
                <div class="alert alert-warning text-center">No hay administradores registrados.</div>
            <?php else: ?>
                <div class="row g-4 justify-content-center">
                    <?php foreach ($admins as $admin): ?>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="card-admin" style="background-color: #e9e6d8ff; color: #000;">
                                <div class="d-flex align-items-center mb-3 gap-3">
                                    <i class="fa fa-user admin-icon"></i>
                                    <div>
                                        <div  class="admin-name"><?= htmlspecialchars($admin['nombre']) ?></div>
                                        <div style="color:black;" class="admin-email"><?= htmlspecialchars($admin['email']) ?></div>
                                    </div>
                                </div>
                                <form method="POST" onsubmit="return confirm('¿Seguro que deseas eliminar a este administrador?');" class="d-flex gap-2">
                                    <input type="hidden" name="eliminar_admin_id" value="<?= $admin['id'] ?>" />
                                    <button type="submit" class="btn btn-outline-danger btn-sm" title="Eliminar administrador" <?php if ($admin['id'] === intval($_SESSION['usuario_id'])) echo 'disabled'; ?>>
                                        <i class="fa fa-trash"></i> Eliminar
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </div>
</section>

<footer class="py-5" style="background-color: #1c1c1c; color: #e0e0e0;">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-3">
                <p class="mb-1">&copy; 2025 Barbería Estilo</p>
                <a href="#" class="text-decoration-none text-secondary me-2">Privacy Policy</a>|
                <a href="#" class="text-decoration-none text-secondary mx-2">Terms of Service</a>|
                <a href="#" class="text-decoration-none text-secondary ms-2">Website Design by YourName</a>
            </div>
            <div class="col-md-4 mb-3 text-center">
                <p class="mb-2">Follow us:</p>
                <a href="https://www.instagram.com/kevin477_/" target="_blank" class="text-white me-3">
                    <i class="fa-brands fa-instagram fa-lg accent"></i>
                </a>
                <a href="#" class="text-white me-3">
                    <i class="fa-brands fa-facebook fa-lg accent"></i>
                </a>
                <a href="#" class="text-white">
                    <i class="fa-brands fa-whatsapp fa-lg accent"></i>
                </a>
            </div>
            <div class="col-md-4 mb-3">
                <p class="mb-1"><strong>Contact:</strong></p>
                <p class="mb-1">Tel: 443-643-8903</p>
                <p class="mb-1">Email: info@barberiaestilo.com</p>
                <p class="mb-0"><strong>Hours:</strong></p>
                <p class="mb-0">Mon - Thurs: 9am - 8pm</p>
                <p class="mb-0">Fri: 9am - 8pm</p>
                <p class="mb-0">Sat: 9am - 4pm</p>
                <p class="mb-0">Sun: Closed</p>
            </div>
        </div>
        <div class="text-center mt-4">
            <a href="#top" class="btn btn-outline-light btn-sm">Back to top</a>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const faders = document.querySelectorAll('.fade-in');
    const appearOptions = { threshold: 0.2, rootMargin: "0px 0px -50px 0px" };
    const appearOnScroll = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if(entry.isIntersecting){
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, appearOptions);
    faders.forEach(fader => appearOnScroll.observe(fader));

    const header = document.querySelector('header');
    window.addEventListener('scroll', () => {
      if(window.scrollY > window.innerHeight - 50){
   header.classList.remove('transparent');
   header.classList.add('solid');
} else {
   header.classList.remove('solid');
   header.classList.add('transparent');
}

    });
</script>
</body>
</html>