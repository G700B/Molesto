<?php
session_start();
include 'conexion.php';
$productos = [];
$result = $con->query("SELECT * FROM productos");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $productos[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Barbería Estilo</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body {
    font-family: 'Segoe UI', sans-serif;
    background-color: #1c1c1c;
    color: #e0e0e0;
    scroll-behavior: smooth;
    zoom: 0.6;

}
header {
    background: transparent !important;
    position: fixed;
    width: 100%;
    z-index: 1000;
    transition: background-color 0.3s ease;
}
header.transparent {
    background-color: transparent !important;
}
header.solid {
    background-color: #1c1c1c !important;
}
header .container-fluid {
    padding-top: 2.5rem;
    padding-bottom: 2.5rem;
}
.navbar-brand.blend-logo {
    font-weight: 600;
    letter-spacing: 3px;
    font-size: 4rem;
}
.nav-link {
    font-size: 1.5rem;
    font-weight: 600;
    letter-spacing: 1.5px;
    color: #E0E0E0 !important;
    transition: color 0.3s ease;
    padding: 2rem 3rem !important;
}
.btn-book-now {
    background-color: #A38C6C;
    color: #fff;
    border: none;
    font-weight: 600;
    padding: 25px 50px;
    transition: all 0.3s ease;
    font-size: 1.4rem;
}
.nav-link:hover {
    color: #C7A86D !important;
}
.btn-book-now:hover {
    background-color: #8C7B5D;
    transform: scale(1.05);
}
.navbar-brand span {
    font-weight: 600;
    letter-spacing: 1px;
}
.btn-primary {
    background-color: #c7a86d;
    border: none;
    transition: all 0.3s ease;
}
.btn-primary:hover {
    background-color: #b08f56;
    transform: scale(1.05);
}
.btn-outline-light:hover {
    background-color: #f1f1f1;
    color: #000;
}
h1, h2, h3, h4 {
    font-family: inherit;
}
section {
    padding: 6rem 0;
}
#inicio {
    background: linear-gradient(to bottom, rgba(0,0,0,0.5), rgba(0,0,0,0.85)), url('../img/R.jpg') center/cover no-repeat;
    color: white;
    text-align: center;
    min-height: 200vh;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
}
#inicio h1 {
    font-size: 3rem;
    font-weight: 700;
    margin-bottom: 1rem;
}
#servicios .card, #comentarios .card, #blend-style .card {
    background-color: #2a2a2a;
    border-radius: 12px;
    padding: 2rem;
    transition: transform 0.4s ease, box-shadow 0.4s ease;
}
#servicios .card:hover, #comentarios .card:hover, #blend-style .card:hover {
    transform: translateY(-10px);
    box-shadow: 0 12px 25px rgba(0,0,0,0.6);
}
#nosotros, #servicios, #blend-style, #faq, #tienda {
    background-color: #2a2a2a;
    color: #e0e0e0;
    border-radius: 12px;
    padding: 3rem;
}
#faq .accordion-item {
    background-color: #2a2a2a;
    border-radius: 12px;
    margin-bottom: 1rem;
}
footer {
    border-top: 1px solid rgba(255,255,255,0.1);
    padding: 2rem 0;
    text-align: center;
}
.accent {
    color: #c7a86d;
}
#blend-style img {
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.5);
    width: 100%;
    height: auto;
    object-fit: cover;
}
.fade-in {
    opacity: 0;
    transform: translateY(20px);
    transition: opacity 0.8s ease, transform 0.8s ease;
}
.fade-in.visible {
    opacity: 1;
    transform: translateY(0);
}
#comentarios .btn-like,
#comentarios .btn-laugh,
#comentarios .btn-wow {
    transition: transform 0.2s, box-shadow 0.2s;
}
#comentarios .btn-like:hover,
#comentarios .btn-laugh:hover,
#comentarios .btn-wow:hover {
    transform: scale(1.1);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}
#comentarios h2.accent {
    color: #c7a86d;
    font-weight: 700;
    letter-spacing: 1px;
}
</style>
</head>
<body>

<header class="p-3 transparent">
    <div class="container-fluid d-flex flex-wrap justify-content-between align-items-center">
        <a href="#inicio" class="navbar-brand blend-logo text-white text-decoration-none ms-3">
            BLEND
        </a>
        <ul class="nav mb-2 mb-md-0 d-flex">
            <li><a href="../index.php" class="nav-link px-3 text-white">INICIO</a></li>
            <li><a href="../index.php#servicios" class="nav-link px-3 text-white"> SERVICES</a></li>
            <li><a href="#" class="nav-link px-3 text-white">COLOR SERVICES</a></li>
            <li><a href="#tienda" class="nav-link px-3 text-white">TIENDA</a></li>
            <li><a href="nosotros.php" class="nav-link px-3 text-white">PELUQUEROS</a></li>
            <li><a href="#" class="nav-link px-3 text-white">CAREERS</a></li>
            <li><a href="#" class="nav-link px-3 text-white">CONTACT</a></li>
        </ul>

        <?php if (isset($_SESSION['usuario_nombre'])): ?>
            <a href="cerrar_sesion.php" class="btn btn-book-now me-3">
                Cerrar sesión (<?php echo htmlspecialchars($_SESSION['usuario_nombre']); ?>)
                <i class="fa-solid fa-user ms-2" style="font-size: 0.8em;"></i>
            </a>
        <?php else: ?>
            <a href="login.php" class="btn btn-book-now me-3">
                LOGIN <i class="fa-solid fa-chevron-down ms-2" style="font-size: 0.8em;"></i>
            </a>
        <?php endif; ?>
    </div>
</header>

<section id="inicio" class="d-flex flex-column justify-content-center align-items-center text-center fade-in">
    <p class="lead mb-4">Certified Invisible Bead Extensions® Stylists and Colorists in Baltimore, MD | Blend Salon</p>
    <h1 class="fw-bold">Our stylists are certified with Invisible Bead Extensions and specialize in Custom Coloring, including blonding & color transformations.</h1>
</section>

<section id="blend-style" class="py-5 fade-in" style="background-color: #ffffffff; color: #000;">
    <div class="container">
        <div class="row align-items-center mb-5">
            <div class="col-md-6 fade-in">
                <img src="./img/one.jpg" alt="Kelsey & Ashley" class="img-fluid rounded shadow" style="width: 400px;">
            </div>
            <div class="col-md-6 fade-in">
                <h3 class="mb-3">Meet Kelsey & Ashley</h3>
                <p>Owners & Lead Extension Specialists. Expertas en brindar el mejor estilo y cuidado en cada visita, combinando técnica profesional y atención personalizada.</p>
                <a href="#" class="btn btn-primary mt-2">Leer más</a>
            </div>
        </div>
        <div class="row align-items-center">
            <div class="col-md-6 order-md-2 fade-in">
                <img src="./img/2.jpg" alt="Nuestros Especialidades" class="img-fluid rounded shadow" style="width: 400px;">
            </div>
            <div class="col-md-6 order-md-1 fade-in">
                <h3 class="mb-3">Nuestros Especialidades</h3>
                <p>Invisible Bead Extensions, Blending y Living in Color. Cada servicio está pensado para realzar tu estilo con cuidado y profesionalismo.</p>
                <a href="#" class="btn btn-primary mt-2">Ver Servicios</a>
            </div>
        </div>
    </div>
</section>

<section id="tienda" class="py-5 fade-in" style="background-color: #e9e6d8ff; color: #e0e0e0;">
    <div class="container">
        <h2 class="text-center mb-5 fw-bold accent">Nuestros Productos</h2>
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <?php if (!empty($productos)): ?>
                <?php foreach ($productos as $producto): ?>
                    <div class="col">
                        <div class="card h-100 shadow border-0" style="background-color: #1c1c1c;">
                            <img src="../img/<?php echo htmlspecialchars($producto['imagen']); ?>" class="card-img-top p-3 rounded" alt="<?php echo htmlspecialchars($producto['nombre']); ?>" style="object-fit: cover; height: 300px;">
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title fw-bold text-white"><?php echo htmlspecialchars($producto['nombre']); ?></h5>
                                <p class="card-text text-white-50 flex-grow-1"><?php echo htmlspecialchars($producto['descripcion']); ?></p>
                                <div class="mt-auto d-flex justify-content-between align-items-center">
                                    <span class="fs-4 fw-bold accent">$<?php echo number_format($producto['precio'], 2); ?></span>
                                    <a href="agregar_al_carrito.php?id=<?php echo htmlspecialchars($producto['id']); ?>" class="btn btn-primary">Comprar <i class="fa-solid fa-cart-shopping ms-2"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-center w-100">No hay productos disponibles en este momento.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<footer class="py-5" style="background-color: #1c1c1cff; color: #e0e0e0;">
<div class="container">
    <div class="row">
        <div class="col-md-4 mb-3">
            <p class="mb-1">&copy; 2025 Barbería Estilo</p>
            <a href="#" class="text-decoration-none text-secondary me-2">Privacy Policy</a>|
            <a href="#" class="text-decoration-none text-secondary mx-2">Terms of Service</a>|
            <a href="#" class="text-decoration-none text-secondary ms-2">Website Design by YourName</a>
        </div>
        <div class="col-md-4 mb-3 text-center">
            <p class="mb-2">Follow us:</p>
            <a href="https://www.instagram.com/kevin477_/" target="_blank" class="text-white me-3">
                <i class="fa-brands fa-instagram fa-lg accent"></i>
            </a>
            <a href="#" class="text-white me-3">
                <i class="fa-brands fa-facebook fa-lg accent"></i>
            </a>
            <a href="#" class="text-white">
                <i class="fa-brands fa-whatsapp fa-lg accent"></i>
            </a>
        </div>
        <div class="col-md-4 mb-3">
            <p class="mb-1"><strong>Contact:</strong></p>
            <p class="mb-1">Tel: 443-643-8903</p>
            <p class="mb-1">Email: info@barberiaestilo.com</p>
            <p class="mb-0"><strong>Hours:</strong></p>
            <p class="mb-0">Mon - Thurs: 9am - 8pm</p>
            <p class="mb-0">Fri: 9am - 8pm</p>
            <p class="mb-0">Sat: 9am - 4pm</p>
            <p class="mb-0">Sun: Closed</p>
        </div>
    </div>
    <div class="text-center mt-4">
        <a href="#inicio" class="btn btn-outline-light btn-sm">Back to top</a>
    </div>
</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const faders = document.querySelectorAll('.fade-in');
    const appearOptions = { threshold: 0.2, rootMargin: "0px 0px -50px 0px" };
    const appearOnScroll = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if(entry.isIntersecting){
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, appearOptions);
    faders.forEach(fader => appearOnScroll.observe(fader));

    const header = document.querySelector('header');
    const inicio = document.querySelector('#inicio');
    window.addEventListener('scroll', () => {
        const inicioHeight = inicio.offsetHeight;
        
if(window.scrollY > window.innerHeight - 50){
   header.classList.remove('transparent');
   header.classList.add('solid');
} else {
   header.classList.remove('solid');
   header.classList.add('transparent');
}

    });
</script>
</body>
</html>