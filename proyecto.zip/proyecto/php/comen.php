<?php
session_start();
include 'conexion.php';


if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}


if (isset($_POST['comentario']) && !empty(trim($_POST['comentario']))) {
    $usuario_id = $_SESSION['usuario_id'];
    $comentario = trim($_POST['comentario']);

    // Insertamos en la base de datos
    $sql = "INSERT INTO comentarios (usuario_id, comentario) VALUES (?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("is", $usuario_id, $comentario);

    if ($stmt->execute()) {
        // Mostrar pantalla de loading antes de redirigir
        ?>
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <title>Comentario enviado</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="../css/loading.css" />
        </head>
        <body style="background: #1c1c1c;">
            <div class="loading-overlay show login">
                <div class="loading-content">
                    <div class="loading-spinner"></div>
                    <div class="loading-text">¡Comentario enviado!</div>
                    <div class="loading-subtitle">Redirigiendo a la página principal...</div>
                    <div class="loading-progress">
                        <div class="loading-progress-bar"></div>
                    </div>
                </div>
            </div>
            
            <script src="../js/loading.js"></script>
            <script>
                // Mostrar loading por 2 segundos y luego redirigir
                setTimeout(function() {
                    window.location.href = '../index.php?comentario_guardado=1';
                }, 2000);
            </script>
        </body>
        </html>
        <?php
        exit();
    } else {
        echo "Error al guardar el comentario: " . $con->error;
    }

} else {
    echo "No se recibió ningún comentario.";
}
?>
