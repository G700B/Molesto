<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es" data-bs-theme="dark">
<head>
    <meta charset="UTF-8" />
    <title>Panel Admin | Calendario</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #1c1c1c;
            color: #e0e0e0;
            scroll-behavior: smooth;
             zoom: 0.6;
        }
        header {
            background: transparent !important;
            position: fixed;
            width: 100%;
            z-index: 1000;
            transition: background-color 0.3s ease;
        }
        header.transparent {
            background-color: transparent !important;
        }
        header.solid {
            background-color: #1c1c1c !important;
        }

        /* Estilos del menú replicados */
        header .container-fluid {
            padding-top: 2.5rem;
            padding-bottom: 2.5rem;
        }
        .navbar-brand.blend-logo {
            font-weight: 600;
            letter-spacing: 3px;
            font-size: 4rem;
        }
        .nav-link {
            font-size: 1.5rem;
            font-weight: 600;
            letter-spacing: 1.5px;
            color: #E0E0E0 !important;
            transition: color 0.3s ease;
            padding: 2rem 3rem !important;
        }
        .btn-book-now {
            background-color: #A38C6C;
            color: #fff;
            border: none;
            font-weight: 600;
            padding: 25px 50px;
            transition: all 0.3s ease;
            font-size: 1.4rem;
        }
        .nav-link:hover {
            color: #C7A86D !important;
        }
        .btn-book-now:hover {
            background-color: #8C7B5D;
            transform: scale(1.05);
        }

        .navbar-brand span {
            font-weight: 600;
            letter-spacing: 1px;
        }
        .btn-primary {
            background-color: #c7a86d;
            border: none;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #b08f56;
            transform: scale(1.05);
        }
        .btn-outline-light:hover {
            background-color: #f1f1f1;
            color: #000;
        }
        h1, h2, h3, h4 {
            font-family: inherit;
        }
        section {
            padding: 6rem 0;
        }
        .accent {
            color: #c7a86d;
        }
        .fade-in {
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 0.8s ease, transform 0.8s ease;
        }
        .fade-in.visible {
            opacity: 1;
            transform: translateY(0);
        }
        
        /* Estilos específicos para el panel de admin */
        #inicio {
            background: linear-gradient(to bottom, rgba(0,0,0,0.5), rgba(0,0,0,0.85)), url('../img/one.jpg') center/cover no-repeat;
            color: white;
            text-align: center;
            min-height: 200vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }
        .main-container {
            padding-top: 15rem; /* Ajuste para el nuevo header */
        }
        .ratio {
            background-color: rgba(42, 42, 42, 0.9);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            overflow: hidden;
            box-shadow: 0 8px 15px rgba(0,0,0,0.4);
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>

<header class="p-3 transparent">
    <div class="container-fluid d-flex flex-wrap justify-content-between align-items-center">
        <a href="panel_admin.php" class="navbar-brand blend-logo text-white text-decoration-none ms-3">
            BLEND
        </a>
        <ul class="nav mb-2 mb-md-0 d-flex">
            <li><a href="panel_admin.php" class="nav-link px-3 text-white">PANEL</a></li>
            <li><a href="agregar_admin.php" class="nav-link px-3 text-white">AGREGAR ADMIN</a></li>
            <li><a href="historial_admin.php" class="nav-link px-3 text-white">HISTORIAL</a></li>
            <li><a href="servicio_admin.php" class="nav-link px-3 text-white">SERVICIOS</a></li>
        </ul>
        <div class="text-end d-flex align-items-center gap-3 me-3">
            <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <i class="fa-solid fa-user-shield"></i> <?= htmlspecialchars($_SESSION['usuario_nombre']) ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar sesión</a></li>
                </ul>
            </div>
        </div>
    </div>
</header>

<section id="inicio" class="d-flex flex-column justify-content-center align-items-center text-center fade-in">
    <div class="container main-container">
        <h2 class="text-center fw-bold my-5 accent">
            <i class="fa fa-calendar-week me-3"></i>Calendario de Turnos
        </h2>
        <div class="ratio ratio-16x9 border border-light border-2 rounded shadow">
            <iframe src="calendario_fc.html" loading="lazy" style="border:none; min-height: 450px;"></iframe>
        </div>
    </div>
</section>

<footer class="py-5" style="background-color: #1c1c1c; color: #e0e0e0;">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-3">
                <p class="mb-1">&copy; 2025 Barbería Estilo</p>
                <a href="#" class="text-decoration-none text-secondary me-2">Privacy Policy</a>|
                <a href="#" class="text-decoration-none text-secondary mx-2">Terms of Service</a>|
                <a href="#" class="text-decoration-none text-secondary ms-2">Website Design by YourName</a>
            </div>
            <div class="col-md-4 mb-3 text-center">
                <p class="mb-2">Follow us:</p>
                <a href="https://www.instagram.com/kevin477_/" target="_blank" class="text-white me-3">
                    <i class="fa-brands fa-instagram fa-lg accent"></i>
                </a>
                <a href="#" class="text-white me-3">
                    <i class="fa-brands fa-facebook fa-lg accent"></i>
                </a>
                <a href="#" class="text-white">
                    <i class="fa-brands fa-whatsapp fa-lg accent"></i>
                </a>
            </div>
            <div class="col-md-4 mb-3">
                <p class="mb-1"><strong>Contact:</strong></p>
                <p class="mb-1">Tel: 443-643-8903</p>
                <p class="mb-1">Email: info@barberiaestilo.com</p>
                <p class="mb-0"><strong>Hours:</strong></p>
                <p class="mb-0">Mon - Thurs: 9am - 8pm</p>
                <p class="mb-0">Fri: 9am - 8pm</p>
                <p class="mb-0">Sat: 9am - 4pm</p>
                <p class="mb-0">Sun: Closed</p>
            </div>
        </div>
        <div class="text-center mt-4">
            <a href="#top" class="btn btn-outline-light btn-sm">Back to top</a>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const faders = document.querySelectorAll('.fade-in');
    const appearOptions = { threshold: 0.2, rootMargin: "0px 0px -50px 0px" };
    const appearOnScroll = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if(entry.isIntersecting){
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, appearOptions);
    faders.forEach(fader => appearOnScroll.observe(fader));

    const header = document.querySelector('header');
    window.addEventListener('scroll', () => {
       
if(window.scrollY > window.innerHeight - 50){
   header.classList.remove('transparent');
   header.classList.add('solid');
} else {
   header.classList.remove('solid');
   header.classList.add('transparent');
}

    });
</script>
</body>
</html>