<?php
session_start();

// Verificar que el usuario esté logueado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../../login.php");
    exit();
}

// Incluir FPDF
require('../fpdf.php');

// Incluir conexión
include("conexion.php");

// Obtener el ID del turno desde URL
$turno_id = $_GET['turno_id'] ?? null;
if (!$turno_id) {
    die("No se especificó el turno.");
}

// Consulta para obtener el turno (misma lógica)
$sql = "SELECT 
            t.*, 
            u.nombre AS cliente, 
            s.nombre AS servicio, 
            mp.nombre AS metodo_pago_nombre,
            s.precio AS precio_servicio
        FROM turnos t
        JOIN usuarios u ON t.usuario_id = u.id
        JOIN servicios s ON t.servicio = s.id
        JOIN metodos_pago mp ON t.metodo_pago = mp.id
        WHERE t.id = ?";

$stmt = $con->prepare($sql);
if (!$stmt) {
    die("Error en la consulta SQL: " . $con->error);
}

$stmt->bind_param("i", $turno_id);
$stmt->execute();
$resultado = $stmt->get_result();
$turno = $resultado->fetch_assoc();

if (!$turno) {
    die("Turno no encontrado.");
}

// ====== ESTILO NUEVO (solo presentación) ======
class PDF extends FPDF {
    public $turno;

    function Header() {
        // Banner superior azul
        $this->SetFillColor(16, 51, 140); // azul
        $this->Rect(0, 0, 210, 60, 'F');
        $this->Image('T.O.png', 12, 2, 30);
           
        // Título FACTURA
        $this->SetFont('Arial', 'B', 28);
        $this->SetTextColor(255, 255, 255);
        $this->SetXY(120, 12);
        $this->Cell(80, 15, 'FACTURA', 0, 1, 'R');

        // Fecha y número dentro del banner
        $this->SetFont('Arial', '', 11);
        $this->SetXY(12, 35);
        $this->Cell(0, 6, 'FECHA: ' . date('d/m/Y'), 0, 1, 'L');
        $this->SetXY(12, 42);
        $this->Cell(0, 6, 'NÚMERO: ' . str_pad($this->turno['id'], 8, '0', STR_PAD_LEFT), 0, 1, 'L');

        // Bloques CLIENTE y EMPRESA
        $this->Ln(10);
        $this->SetY(68);

        $azul = [16, 51, 140];

        // Titulares
        $this->SetFont('Arial', 'B', 12);
        $this->SetTextColor($azul[0], $azul[1], $azul[2]);
        $this->Cell(100, 6, 'CLIENTE:', 0, 0, 'L');
        $this->Cell(100, 6, 'EMPRESA:', 0, 1, 'L');

        // Contenido
        $this->SetFont('Arial', '', 11);
        $this->SetTextColor(0, 0, 0);

        // Columna cliente
        $xL = 10; $yBase = 78;
        $this->SetXY($xL, $yBase);
        $this->Cell(100, 6, $this->turno['cliente'], 0, 1, 'L');
        $this->SetX($xL); $this->Cell(100, 6, '—', 0, 1, 'L'); // líneas de cortesía
        $this->SetX($xL); $this->Cell(100, 6, '—', 0, 1, 'L');

        // Columna empresa (texto fijo del ejemplo)
        $xR = 110;
        $this->SetXY($xR, $yBase);
        $this->SetFont('Arial', 'B', 11);
        $this->Cell(90, 6, 'Estudio Shonos', 0, 1, 'L');
        $this->SetFont('Arial', '', 11);
        $this->SetX($xR); $this->Cell(90, 6, 'Calle Cualquiera 123,', 0, 1, 'L');
        $this->SetX($xR); $this->Cell(90, 6, 'Cualquier Lugar, CP:12345', 0, 1, 'L');
        $this->SetX($xR); $this->Cell(90, 6, '911-234-567', 0, 1, 'L');
        $this->SetX($xR); $this->Cell(90, 6, 'hola@unsitiogenial.es', 0, 1, 'L');

        $this->Ln(6);

        // Encabezado de la tabla (3 columnas como la imagen)
        $this->SetFont('Arial', 'B', 12);
        $this->SetFillColor($azul[0], $azul[1], $azul[2]);
        $this->SetTextColor(255, 255, 255);
        $this->Cell(120, 10, 'DESCRIPCIÓN', 1, 0, 'C', true);
        $this->Cell(30, 10, 'CANTIDAD', 1, 0, 'C', true);
        $this->Cell(40, 10, 'IMPORTE', 1, 1, 'C', true);
    }

    function Footer() {
        // Observaciones (sobre el pie, lado izq.)
        $this->SetY(-48);
        $this->SetFont('Arial', 'B', 11);
        $this->SetTextColor(16, 51, 140);
        $this->Cell(120, 7, 'OBSERVACIONES:', 0, 1, 'L');

        $this->SetFont('Arial', '', 9);
        $this->SetTextColor(0, 0, 0);
        $this->MultiCell(120, 5, "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim.");

        // Barra inferior azul con marca
        $this->SetFillColor(16, 51, 140);
        $this->Rect(0, 285, 210, 12, 'F'); // barra
        $this->SetY(-12);
        $this->SetFont('Arial', 'B', 10);
        $this->SetTextColor(255, 255, 255);
        $this->Cell(0, 10, 'ESTUDIO SHONOS', 0, 0, 'C');
    }
}

// Crear PDF
$pdf = new PDF();
$pdf->turno = $turno;
$pdf->AliasNbPages();
$pdf->AddPage();

// ====== CUERPO (misma lógica, distinta presentación) ======
$pdf->SetFont('Arial', '', 11);
$pdf->SetTextColor(0, 0, 0);

// Datos del turno principal
$valor_unitario = $turno['precio'] ?? 0; // respeta tu variable
$cantidad = 1;
$total = $valor_unitario * $cantidad;

// Fila principal (3 columnas: descripción, cantidad, importe)
$pdf->Cell(120, 10, $turno['servicio'], 1, 0, 'L');
$pdf->Cell(30, 10, $cantidad, 1, 0, 'C');
$pdf->Cell(40, 10, '$' . number_format($valor_unitario, 0, ',', '.'), 1, 1, 'R');

// Si hay seña, fila gris suave
if (!empty($turno['senia'])) {
    $pdf->SetFillColor(240, 240, 240);
    $pdf->Cell(120, 10, 'SEÑA', 1, 0, 'L', true);
    $pdf->Cell(30, 10, '-', 1, 0, 'C', true);
    $pdf->Cell(40, 10, '$' . number_format($turno['senia'], 0, ',', '.'), 1, 1, 'R', true);
}

// Segundo servicio (si existe), misma lógica
if (!empty($turno['servicio_2'])) {
    $sql2 = "SELECT nombre, precio FROM servicios WHERE id = ?";
    $stmt2 = $con->prepare($sql2);
    $stmt2->bind_param("i", $turno['servicio_2']);
    $stmt2->execute();
    $res2 = $stmt2->get_result();
    $serv2 = $res2->fetch_assoc();
    $precio2 = $serv2['precio'] ?? 0;

    $pdf->Cell(120, 10, $serv2['nombre'], 1, 0, 'L');
    $pdf->Cell(30, 10, 1, 1, 0, 'C'); // cantidad 1
    $pdf->Cell(40, 10, '$' . number_format($precio2, 0, ',', '.'), 1, 1, 'R');

    $total += $precio2;
}

// Relleno de líneas vacías para estética (opcional, como la imagen)
for ($i = 0; $i < 6; $i++) {
    $pdf->Cell(120, 10, '', 1, 0);
    $pdf->Cell(30, 10, '', 1, 0);
    $pdf->Cell(40, 10, '', 1, 1);
}

// ====== CAJA DE TOTALES A LA DERECHA (BASE / IVA / IRPF / TOTAL) ======
$base = $total;       // sin impuestos (como en la imagen)
$iva  = 0;
$irpf = 0;
$total_general = $base + $iva - $irpf;

// Posicionar caja al lado derecho
$yBox = $pdf->GetY() + 4;
if ($yBox > 230) { // por si se acerca al pie
    $pdf->AddPage();
    $yBox = 80;
}
$pdf->SetXY(130, $yBox);

$azul = [16, 51, 140];
$pdf->SetFont('Arial', 'B', 11);

// Fila BASE
$pdf->SetFillColor($azul[0], $azul[1], $azul[2]);
$pdf->SetTextColor(255,255,255);
$pdf->Cell(40, 9, 'BASE', 1, 0, 'C', true);
$pdf->SetTextColor(0,0,0);
$pdf->SetFont('Arial','',11);
$pdf->Cell(40, 9, '$' . number_format($base, 0, ',', '.'), 1, 1, 'R');

// Fila IVA
$pdf->SetFont('Arial','B',11);
$pdf->SetFillColor($azul[0], $azul[1], $azul[2]);
$pdf->SetTextColor(255,255,255);
$pdf->Cell(40, 9, 'IVA', 1, 0, 'C', true);
$pdf->SetTextColor(0,0,0);
$pdf->SetFont('Arial','',11);
$pdf->Cell(40, 9, '$' . number_format($iva, 0, ',', '.'), 1, 1, 'R');

// Fila IRPF
$pdf->SetFont('Arial','B',11);
$pdf->SetFillColor($azul[0], $azul[1], $azul[2]);
$pdf->SetTextColor(255,255,255);
$pdf->Cell(40, 9, 'IRPF', 1, 0, 'C', true);
$pdf->SetTextColor(0,0,0);
$pdf->SetFont('Arial','',11);
$pdf->Cell(40, 9, '$' . number_format($irpf, 0, ',', '.'), 1, 1, 'R');

// Fila TOTAL
$pdf->SetFont('Arial','B',11);
$pdf->SetFillColor($azul[0], $azul[1], $azul[2]);
$pdf->SetTextColor(255,255,255);
$pdf->Cell(40, 9, 'TOTAL', 1, 0, 'C', true);
$pdf->SetTextColor(0,0,0);
$pdf->SetFont('Arial','',11);
$pdf->Cell(40, 9, '$' . number_format($total_general, 0, ',', '.'), 1, 1, 'R');

// Salida del PDF (misma)
$pdf->Output('I', 'Comprobante_' . $turno['id'] . '.pdf');
?>
