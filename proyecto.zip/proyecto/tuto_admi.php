<?php
session_start();

// Verificar que el usuario sea admin
if (!isset($_SESSION['usuario_rol']) || $_SESSION['usuario_rol'] !== 'admin') {
    header("Location: ../../login.php");
    exit();
}

// Incluir FPDF
require('../fpdf.php');

// Incluir conexión
include("conexion.php");

// Obtener el ID del turno desde URL
$turno_id = $_GET['turno_id'] ?? null;
if (!$turno_id) {
    die("No se especificó el turno.");
}

// Consulta para obtener el turno completo
$sql = "SELECT 
            t.*, 
            u.nombre AS cliente, 
            s.nombre AS servicio, 
            mp.nombre AS metodo_pago_nombre
        FROM turnos t
        JOIN usuarios u ON t.usuario_id = u.id
        JOIN servicios s ON t.servicio = s.id
        JOIN metodos_pago mp ON t.metodo_pago = mp.id
        WHERE t.id = ?";

$stmt = $con->prepare($sql);
if (!$stmt) {
    die("Error en la consulta SQL: " . $con->error);
}

$stmt->bind_param("i", $turno_id);
$stmt->execute();
$resultado = $stmt->get_result();
$turno = $resultado->fetch_assoc();

if (!$turno) {
    die("Turno no encontrado.");
}

// Clase PDF personalizada
class PDF extends FPDF {
    public $turno;

    function Header() {
        if(file_exists('../../logo.png')){
            $this->Image('../../logo.png',20,6,60);
        }
        $this->SetFont('Arial','',10);
        $this->SetY(1);
        $this->Cell(170,10,'Factura de Venta N '.$this->turno['id'],0,1,'R');
        $this->Ln(40);

        $this->Cell(100,10,'Cliente: '.$this->turno['cliente'],0,0);
        $this->Cell(90,10,'Factura N: '.$this->turno['id'],0,1);
        $this->Cell(100,10,'Metodo de Pago: '.$this->turno['metodo_pago_nombre'],0,1);
        $this->Cell(100,10,'Fecha de Turno: '.$this->turno['fecha'],0,0);
        $this->Cell(90,10,'Hora: '.$this->turno['hora'],0,1);
        $this->Ln(10);

        $this->SetFont('Arial','B',12);
        $this->Cell(80,10,'Servicio',1,0,'C');
        $this->Cell(30,10,'Cant',1,0,'C');
        $this->Cell(40,10,'Valor Unitario',1,0,'C');
        $this->Cell(40,10,'Valor Total',1,1,'C');
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial','I',8);
        $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
    }
}

// Crear PDF
$pdf = new PDF();
$pdf->turno = $turno;
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','',12);

// Servicio principal
$valor_unitario = $turno['precio'] ?? 0;
$cantidad = 1;
$total = $valor_unitario * $cantidad;

$pdf->Cell(80,10,$turno['servicio'],1);
$pdf->Cell(30,10,$cantidad,1,0,'C');
$pdf->Cell(40,10,'$'.number_format($valor_unitario,0,',','.'),1,0,'R');
$pdf->Cell(40,10,'$'.number_format($total,0,',','.'),1,1,'R');

// Si hay seña
if(!empty($turno['senia'])){
    $pdf->Cell(150,10,'SEÑA',1);
    $pdf->Cell(40,10,'$'.number_format($turno['senia'],0,',','.'),1,1,'R');
}

// Servicio 2 si existe
if(!empty($turno['servicio_2'])){
    $sql2 = "SELECT nombre, precio FROM servicios WHERE id = ?";
    $stmt2 = $con->prepare($sql2);
    $stmt2->bind_param("i", $turno['servicio_2']);
    $stmt2->execute();
    $res2 = $stmt2->get_result();
    $serv2 = $res2->fetch_assoc();
    $precio2 = $serv2['precio'] ?? 0;

    $pdf->Cell(80,10,$serv2['nombre'],1);
    $pdf->Cell(30,10,1,1,0,'C');
    $pdf->Cell(40,10,'$'.number_format($precio2,0,',','.'),1,0,'R');
    $pdf->Cell(40,10,'$'.number_format($precio2,0,',','.'),1,1,'R');

    $total += $precio2;
}

// Total general
$pdf->Cell(150,10,'TOTAL GENERAL',1);
$pdf->Cell(40,10,'$'.number_format($total,0,',','.'),1,1,'R');

// Salida PDF
$pdf->Output('I','Comprobante_'.$turno['id'].'.pdf');

?>
